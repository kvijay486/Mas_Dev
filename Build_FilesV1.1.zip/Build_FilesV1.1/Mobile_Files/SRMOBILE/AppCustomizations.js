/**
*** Custom Application Logic
*** 
***
*/
import { AppSwitcher } from '@maximo/maximo-js-api';
import { Device, log, JSONDataAdapter } from '@maximo/maximo-js-api';

class AppCustomizations {
  applicationInitialized(app) {
    this.app = app;
    /*
    * Move directly to create SR if this a follow up from work order
    */
    const incomingContext = this.app && this.app.state && this.app.state.incomingContext;
    if (incomingContext && incomingContext.followup) {
      this.app.setCurrentPage(
        {
          name: 'newRequest',
          resetScroll: true,
          params: { followup: 'true', woItem: incomingContext.woItem }
        }
      );
    }
  }
  async onBeforeLoadData(Datasource, Query) {
    if (Device.get().isMaximoMobile && Query.searchText && !this.page.state.setSearchTextToOriginal && !(Datasource.dataAdapter instanceof JSONDataAdapter)) {
      this.page.state.searchBeforeReplace = Query.searchText;
      Query.searchText = this.replaceSpecialCharacters(Query.searchText);
      this.setSearchTextToOriginal(Datasource.name, this.page.state.searchBeforeReplace)
    }
  }

  /*
  * Custom addition
  * Capture a reference to the Page
  * new method pageResumed called everytime Page accessed
  * Must exist so app and page remains available/up-to-date through this.app, this.page in need of accessing this.page.state for example
  */
  pageResumed(page, app) {
    this.app = app;
    this.page = page;
  }

  /*
  * Use pageInitialized to set correct title on page 
  * and catch- and extend pageResumed-function in CreateSRController to extend with initial values from work order
  */
  async pageInitialized(page) {
    if (page.name === 'newRequest') {
      const incomingContext = this.app && this.app.state && this.app.state.incomingContext;
      page.state.followup = false;
      if (incomingContext && incomingContext.followup)
        page.state.followup = true;
    }
    else if (page.name === 'createSR') {
      const incomingContext = this.app && this.app.state && this.app.state.incomingContext;
      let isFollowup = false;
      if (incomingContext && incomingContext.followup)
        isFollowup = true;
      let ctrl = page.controllers[0];
      /*
      * pageResumed
      * Use async and await pageResumed here to make sure it runs through before setInitialDataFromWO is executed
      */
      let oldpageResumed = ctrl.pageResumed.bind(ctrl);
      let loadHub = ctrl.loadHub.bind(ctrl);
      ctrl.pageResumed = async (evt) => {
        //before 
        let savedDataExists = this.app.state.valuesaved;
        //await originalpageResumed
        await oldpageResumed(evt);
        //after, set initial wo data
        if (isFollowup)
          await this.setInitialDataFromWO(evt, savedDataExists);
          await loadHub();
      }

      /*
      * createServiceRequestSubmit, execute custom function if followup otherwise go for standard function
      */
      let oldcreateServiceRequestSubmit = ctrl.createServiceRequestSubmit.bind(ctrl);
      ctrl.createServiceRequestSubmit = (evt) => {
        //Before we call createServiceRequestSubmit, we check if the required fields have a value
        //..if not, return to stop the call for createServiceRequestSubmit.
        if (this.checkRequiredFields()) return;
        if (isFollowup)
          this.createServiceRequestSubmit(evt);
        else
          oldcreateServiceRequestSubmit(evt);
      }

      /*
      * openPrevPage, execute custom function if followup otherwise go for standard function
      */
      let oldopenPrevPage = ctrl.openPrevPage.bind(ctrl);
      ctrl.openPrevPage = () => {
        if (isFollowup)
          this.openPrevPage();
        else
          oldopenPrevPage();
      }
    }
  }

  /*
  * Function that use values passed from work order to populate the new ticket
  */
  async setInitialDataFromWO(page, hasSavedData) {
    //Fetch woItem passed from technican application
    let origWO = this.app.state.incomingContext.woItem;
    let srDS = this.app.findDatasource("srDS"); // Cust
    /*
    * Addition to relate new ticket with originator WO. This will create a related record when posting to Maximo.
    * Use reference to wonum and woclass
    */
    srDS.item["origrecordid"] = origWO["wonum"];
    srDS.item["origrecordclass"] = origWO["woclass"];

    if (origWO["orgid"]) {
      srDS.item["orgid"] = origWO["orgid"];
      srDS.item["origrecorgid"] = origWO["orgid"];
    }
    if (origWO["siteid"]) {
      srDS.item["siteid"] = origWO["siteid"];
      srDS.item["origrecsiteid"] = origWO["siteid"];
    }
    //Only effect this data if user hasn't any temporary dataset saved
    if (!hasSavedData) {
      if (origWO["assetnum"]) {
        let asset = { 'assetnum': origWO["assetnum"], 'description': origWO["assetdesc"], 'location': origWO["locationnum"], 'locationdesc': origWO["locationdesc"], 'orgid': origWO["orgid"], 'siteid': origWO["siteid"] };
        let ctrl = page.controllers[0];
        await ctrl.selectAsset(asset);
      }
      else if (origWO["locationnum"]) {
        let loc = { 'location': origWO["locationnum"], 'description': origWO["locationdesc"], 'orgid': origWO["orgid"], 'siteid': origWO["siteid"] };
        let ctrl = page.controllers[0];
        await ctrl.selectLocation(loc);
      }

      if (this.app.state.isMobileContainer)
        srDS.item["description"] = origWO["description"];
      else
        srDS.item["description"] = origWO["wodesc"];
    }

    //page.state.splitViewIndex = 0;
    let ctrl = this.page.controllers[0];
    await ctrl.loadHub();
  }

  /*
  * Override function openPrevPage in CreateSRController
  */
  async openPrevPage() {
    // Make sure that the dialog will be displayed
    this.page.state.useConfirmDialog = true;
    this.app.state.isback = true;
    if (this.app.state.pagelist.length > 0 || this.app.state.valuesaved) {
      // istanbul ignore else
      let popcurrentitem;
      if (!this.app.state.valuesaved) {
        popcurrentitem = this.app.state.pagelist.pop();
      }
      let currentitem = popcurrentitem;
      // istanbul ignore else
      if (currentitem) {
        this.app.state.backPageName = currentitem.pagename;
        this.app.state.isFromDescribleReq = currentitem.isFromDescribleReq;
        if (this.app.state.backPageName === 'SubCategory') {
          this.app.state.selectedSubCategory = currentitem.id;
          this.app.state.subcategory = currentitem.description;
          this.app.state.currSubCategoryID = currentitem.currID;
          this.app.state.currSubCategoryDesc = currentitem.currDesc;
          this.app.setCurrentPage({ name: this.app.state.backPageName });
          console.log(">>>>>>Back to Subcategory Page from CreateSR page, this.app.state.lastCurrSelectedID= ", this.app.state.lastCurrSelectedID);
          console.log(">>>>>>Back to Subcategory Page from CreateSR page, data{id, description, currID, currDesc}:", currentitem.id, currentitem.description, currentitem.currID, currentitem.currDesc);
          console.log("Back to Subcategory Page from CreateSR page, Length=", this.app.state.pagelist.length);
        } else if (this.app.state.backPageName === 'tktemp') {

          this.app.state.templateid = currentitem.id;

          this.app.setCurrentPage({ name: this.app.state.backPageName, params: { lastcategorydesc: currentitem.description } });
          console.log("Back to Ticket Template Page from CreateSR page, Length=", this.app.state.pagelist.length);
        } else {
          /*
          * Custom addition START
          * Pin point page newRequest in this section instead of state.backPageName
          */
          this.app.setCurrentPage({ name: 'newRequest' });
          this.page.state.navigateBack = true;
          console.log("Go back to the previous page - newRequest");
          /*
          * Custom addition END
          */
        }
      }
    } else {
      this.app.setCurrentPage({ name: 'newRequest' });
      this.page.state.navigateBack = true;
      console.log("Go back to the previous page - newRequest");
    }
    let ctrl = this.page.controllers[0];
    ctrl.resetPageDatasources();
  }

  /*
  * Override function createServiceRequestSubmit in CreateSRController
  */
  async createServiceRequestSubmit(doSubmit) {
    if(doSubmit) {
	let ctrl = this.page.controllers[0];
    let srCreateResource = this.app.findDatasource("srDS");
    ctrl.setTicketPriority();
    try {
      if(this.page.state.location) {
        srCreateResource.item["location"] = this.page.state.location;
      }
      if(this.page.state.assetnum) {
        srCreateResource.item["assetnum"] = this.page.state.assetnum;
      }
	  //istanbul ignore next
      if(this.page.state.formattedaddress) {
        srCreateResource.item["formattedaddress"] = this.page.state.formattedaddress;
      }
	  //istanbul ignore next
      if(this.page.state.streetaddress) {
        srCreateResource.item["streetaddress"] = this.page.state.streetaddress;
      }
	  //istanbul ignore next
      if(this.page.state.city) {
        srCreateResource.item["city"] = this.page.state.city;
      }
	  //istanbul ignore next
      if(this.page.state.stateprovince) {
        srCreateResource.item["stateprovince"] = this.page.state.stateprovince;
      }
	  //istanbul ignore next
      if(this.page.state.latitudey) {
        srCreateResource.item["latitudey"] = this.page.state.latitudey;
      }
	  //istanbul ignore next
      if(this.page.state.longitudex) {
        srCreateResource.item["longitudex"] = this.page.state.longitudex;
      }
      /**if asset and location mismatch, user choose to keep the mismatch, set interactive=0 to avoild maximo side throw error message to ask user confirm again. */
	    //istanbul ignore next
      if(this.page.state.assetlocationmismatch){
        srCreateResource.options.query.interactive = 0;
      }else{
        srCreateResource.options.query.interactive = 1;
      }

      await ctrl.preparePersonInfoForSave();

      //DT197320 Error while creating an SR with location in Service Request
        // istanbul ignore next
        if(srCreateResource.item["location"] && srCreateResource.item["assetorgid"] === "" && srCreateResource.item["assetsiteid"] === ""){
          if(this.page.state.orgid && this.page.state.siteid){
            srCreateResource.item["assetorgid"] = this.page.state.orgid;
            srCreateResource.item["assetsiteid"] = this.page.state.siteid;
          }
        }
        //END OF DT

      // include Service Address information for saving SR
      srCreateResource.item.tkserviceaddress = {
        formattedaddress: this.page.state.formattedaddress,
        streetaddress: this.page.state.streetaddress,
        city: this.page.state.city,
        stateprovince: this.page.state.stateprovince,
        latitudey: this.page.state.latitudey,
        longitudex: this.page.state.longitudex,
        class: this.app.state.synonym.srClass.value,
      }

      this.page.state.noConfirm = true;
      this.page.state.useConfirmDialog = false;
      const isContainer = await this.app.state.isMobileContainer;

      //istanbul ignore next
      if(srCreateResource.item && srCreateResource.item.ticketspec && !this.page.params?.editTrans)
      {
        let newTicketSpecJDS = this.page.datasources['newTicketSpecJDS'];
        srCreateResource.item.ticketspec = newTicketSpecJDS.items;
        for (let i=0; i < srCreateResource.item.ticketspec.length; i++) {
          let ticketSpec = srCreateResource.item.ticketspec[i];
          let remFromTicketSpec = [
            'templateid',
            'tktemplatespecid',
            '_rowstamp'
          ];
          if (!isContainer) {
            remFromTicketSpec.push('href');
          }
          remFromTicketSpec.forEach(e => Reflect.deleteProperty(ticketSpec, e));       
        }

      }
     
      this.app.state.refreshActiveRequests = true;


      //remove site tag to prevent try insert site again
      // istanbul ignore if	    
      if (srCreateResource.item.site){
        delete srCreateResource.item.site;
      } 

      let response;
      try {
        response = await srCreateResource.save({interactive: false});
      } catch(error) {
        //istanbul ignore next
        log.t(TAG, error);
      } finally {
        //istanbul ignore if
        if (response && response.error) {
          this.app.toast(null, "error", response.error.message, 5000, false, false);
          return;
        }
      }

      //Response will now be the selected SR to be displayed in details page
      this.app.state.selectedSR = response.items[0];

      //When SR is created on device, these variables need to be manually set
      if (this.app.state.isMobileContainer) {
        this.app.state.selectedSR.status_description = this.app.state.synonym.newSRStatus.description;
        this.app.state.selectedSR.reportedpriority_description = this.app.state.numericDom.priorityDescriptionList[this.app.state.selectedSR.reportedpriority];
        this.app.state.selectedSR.computedSRDescription = this.app.state.selectedSR.description;
        this.app.state.selectedSR.computedSRStatusPriority = [
          {
            label: this.app.state.selectedSR.status_description,
            type: 'cool-gray'
          },
          {
            label: this.app.state.selectedSR.reportedpriority_description,
            type: 'dark-gray'
          }
        ];
        const worklogItems = await this.app.findDatasource("worklogDS").forceReload();
        this.app.state.selectedSR.computedWorklogCount = worklogItems.length;
        this.app.state.selectedSR.computedDoclinksCount = (srCreateResource.item.doclinks)? srCreateResource.item.doclinks.member.length : 0;
      } else {
        this.app.state.selectedSR.computedWorklogCount = 0;
        this.app.state.selectedSR.computedDoclinksCount = 0;
      }

      //Go to SR details page
      this.app.setCurrentPage({
        name: "srDetails",
        resetScroll: true,
        params: {
          doclinksCountOverridden: false
        }
      });
      //Display ticket created message
      let label = "";
      //istanbul ignore if (In tests we do not have a returned SR with ticketid in the save)
      if (this.app.state.selectedSR?.ticketid) {
        label = this.app.getLocalizedMessage(this.app.name, 'srCreated_msg', 'Request {0} submitted', [response.items[0].ticketid]);
      } else {
        label = this.app.getLocalizedMessage(this.app.name, 'srCreated_nonumber_msg', 'Request submitted');
      }
      //this.app.toast(label, "error","", 5000, false,false);
      this.app.toast(label, 'success');
      srCreateResource.clearState();
      srCreateResource.resetState();
      srCreateResource.forceReload();
        /*
           * Custom addition START
           * Return to originator work order, exclude "Display ticket created message" and "Go to main page" from standard
           */
        let switcher = AppSwitcher.get();
        if (switcher.hasReturnToApp()) {
          let followuptk = {};
          if (response?.items[0]?.ticketid)
            followuptk = { 'followuptk': 1, 'label': this.app.getLocalizedLabel('srCreated_msg', 'Request {0} submitted', [response.items[0].ticketid]) };
          else
            followuptk = { 'followuptk': 1, 'label': this.app.getLocalizedLabel('srCreated_nonumber_msg', 'Request submitted') };

          switcher.returnToApplication(followuptk);
        }
        /*
        * Custom addition END
        */
      } catch (error) {
        // istanbul ignore next
        //log.t(TAG, error);
      } finally {
        srCreateResource.off('save-data-failed', ctrl.onSaveDataFailed);
        this.page.state.noConfirm = false;
        this.page.state.useConfirmDialog = true;
        ctrl.resetPageDatasources();
      }

    }
  }
  replaceSpecialCharacters(inputString) {
    var regex = /[ÿáàâãäåéèêëíîïóôöúüñçǽȳḧ]/g;
    var replacedString = inputString.replace(regex, "%");
    return replacedString;
  }
  async setSearchTextToOriginal(datasourceName, originalSearchText) {
    const ds = await this.app.findDatasource(datasourceName);
    this.page.state.setSearchTextToOriginal = true;
    await ds.load({ pageSize: ds.lastQuery.pageSize, size: ds.lastQuery.size, start: ds.lastQuery.start })
    this.page.state.setSearchTextToOriginal = undefined;
    ds.state.currentSearch = originalSearchText;
  }
  async custOpenLocationLookup(evt) {
    //Standard datasource
    const dsCreateSr = evt.app.findDatasource("srDS");
    //Custom json-datasource
    let custjLoc = evt.app.findDatasource("custjLocation");
    //Clear and reset
    custjLoc.clearState();
    custjLoc.resetState();
    //Show dialog
    evt.page.showDialog("custEnhancedLocationLookup");
    //Check actual location value, if no location-value to filter with don't fetch any values
    if (dsCreateSr.item) {
      const locval = dsCreateSr.item.location;
      if (locval && locval !== "") {
        const locDS = evt.app.findDatasource("locationLookupDS");
        if (locDS) {
          //Set state loading to visualize the loading indicator for end user
          custjLoc.state.loading = true;
          //Remove any previous filter on locationLookupDS
          locDS.clearState();
          locDS.resetState();
          await locDS.initializeQbe();
          //If mobile use %value% syntax, otherwise (web/pc) value% syntax works.
          if (Device.get().isMaximoMobile)
            locDS.setQBE("location", "%" + locval + "%");
          else
            locDS.setQBE("location", locval + "%");

          //Use load with pagesize otherwise limited to 100
          let locitems = await locDS.load({ pageSize: 4000 });
          let selectedItem;
          let tempArr = [];
          locitems.forEach((item) => {
            if (item.location === locval) {
              selectedItem = item;
            }
            //If Mobile device, validate that location starts with the correct value to get rid of those that not qualify for value%-syntax
            if (Device.get().isMaximoMobile) {
              if (item.location.startsWith(locval))
                tempArr.push(item);
            }
            else
              tempArr.push(item);
          });

          locitems = tempArr;

          //Load data to custom json-datasource
          await custjLoc.load({ src: locitems, noCache: true });
          if (selectedItem) {
            custjLoc.setSelectedItem(selectedItem, true);
          }
          //Reset filter on standard datasource locationLookupDS
          locDS.clearState();
          locDS.resetState();
        }
      }
    }
  }
  //Method to check if all required fields when creating a service request have a value
  checkRequiredFields() {
    console.log(">>>>>> In Check Required Fields method");
    let mytest1 ;
    let srDS = this.app.findDatasource("srDS");
    if (!(srDS.item["location"] && srDS.item["description"] && srDS.item["description_longdescription"])) {
      this.page.showDialog('cannotSubmit');
      this.app.state.pageLoading = false;
      return true;
    }
    return false;
  }
  async onAfterLoadData(Datasource, Items, Query) {

    //Set "requiredstate" value to true on SRListds items which corresponds to Details/Location to correctly render
    //the visual representation of the fields being required
    if (Datasource.name === "SRListds" && Items.length > 1) {
      Items[0].requiredstate = true; //Details
      Items[2].requiredstate = true; //Location
      console.log("SRListds", this.app.findDatasource("SRListds"))
    }
  }

}


export default AppCustomizations;