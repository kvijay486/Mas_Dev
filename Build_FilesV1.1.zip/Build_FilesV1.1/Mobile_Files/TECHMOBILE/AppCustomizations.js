// Custom Application Logic

import WOTimerUtil from './utils/WOTimerUtil';
import { Device, log, JSONDataAdapter, Browser } from '@maximo/maximo-js-api';
import SynonymUtil from './utils/SynonymUtil';
import WOUtil from './utils/WOUtil';

class AppCustomizations {
  applicationInitialized(app) {
    this.app = app;

    let c = app.controllers[0]

    //IT02959244 - Automatically select NO if GL-question is asked in woedit page 
    //This logic is executed for RBA only
    if (!Device.get().isMaximoMobile) {
      let uiManager = this.app.userInteractionManager;
      let oldYncToDialog = uiManager.yncToDialog.bind(uiManager);
      uiManager.yncToDialog = (yncDialog) => {
        //Make sure to only run on woedit page and for error msg
        //"BMXAA4510E - The location and asset combination you have entered would default a different GL account than is currently specified on the work order..."
        if (
          this.page.name === "woedit" &&
          !this.page.params.followup &&
          yncDialog.Error.reasonCode === "BMXAA4510E"
        ) {
          try {
            //Remove Yes-alternative to make sure that the user only will have No to choose from if the automated "press No btn"-feature is failing.
            delete yncDialog.yncuserinputoptions.yes;
            return oldYncToDialog(yncDialog);
          } finally {
            //Wait until element for "No"-answer is available in UI. max 5 tries
            this.waitForElement(
              "#undefined_button_group_undefined_secondary_button",
              50,
              5
            )
              .then((element) => {
                element.click();
              })
              .catch((error) => {
                console.error(error.message);
              });
          }
        } else return oldYncToDialog(yncDialog);
      };
    }

    //IT02969062 - Possibility to change status from FCOMP to INPRG in mobile
    //isValidTransitionMaxVal is a method on the appcontroller which has these hardcoded values deciding which status maxvalues are allowed
    //for certain statuses. We add 'INPRG' to the array containing allowed statuschanges from the 'COMP' maxvalue. 
    /*c._isValidTransitionMaxVal = (from, to) => {
      const TAG = 'TechnicianApp'; //Usually set at top level of AppController, but for the logging to work we set it here in this overwrite of the method
      log.t(TAG, 'isValidTransition : from --> ' + from + ' to --> ' + to);
      let transitionMatrix = {
        WAPPR: [
          'WAPPR',
          'INPRG',
          'CAN',
          'WMATL',
          'COMP',
          'APPR',
          'CLOSE',
          'WSCH'
        ],
        WPCOND: ['APPR', 'CAN', 'CLOSE', 'COMP', 'INPRG', 'WAPPR', 'WMATL', 'WSCH'],
        APPR: ['APPR', 'INPRG', 'WMATL', 'COMP', 'WAPPR', 'CLOSE', 'CAN', 'WSCH'],
        WSCH: ['WSCH', 'INPRG', 'WMATL', 'COMP', 'WAPPR', 'CLOSE', 'APPR', 'CAN'],
        WMATL: ['WMATL', 'INPRG', 'COMP', 'WAPPR', 'CLOSE', 'CAN'],
        INPRG: ['INPRG', 'WMATL', 'COMP', 'WAPPR', 'CLOSE'],
        COMP: ['INPRG', 'COMP', 'CLOSE'],
        CLOSE: ['CLOSE'],
        CAN: ['CAN']
      };
      if (!transitionMatrix[from] || transitionMatrix[from].indexOf(to) < 0) {
        // Not a valid transition ..
        log.t(TAG, 'isValidTransition : Not a valid transition .. ');
        return false;
      } else {
        // Is a valid transition ..
        log.t(TAG, 'isValidTransition : Is a valid transition .. ');
        return true;
      }
    }*/

  }
  async onBeforeLoadData(Datasource, Query) {
    if (Device.get().isMaximoMobile && Query.searchText && !this.page.state.setSearchTextToOriginal && !(Datasource.dataAdapter instanceof JSONDataAdapter)) {
      this.page.state.searchBeforeReplace = Query.searchText;
      Query.searchText = this.replaceSpecialCharacters(Query.searchText);
      this.setSearchTextToOriginal(Datasource.name, this.page.state.searchBeforeReplace)
    }
  }
  async onAfterLoadData(Datasource, Item, Query) {

    if (Device.get().isMaximoMobile && Datasource.name === "dsFailureList" && Item.length) {
      /**
      * 8.8 specific issue when on mobile device and using preloaded DB since attribute
      * type_maxvalue is not included even though REST API and Object structure is returning the data.
      * This is also why it works well when using RBA and/or mobile device without preloaded DB.
      * Addings this information to items on after load when needed.
      * item.type only defined/used on PROBLEM, CAUSE, REMEDY - setting maxvalue to same as type 
      **/
      Item.forEach((failItem) => {
        if (failItem.type && !failItem.type_maxvalue)
          failItem.type_maxvalue = failItem.type;
      });
    }

  }

  //Custom function to wait until specific UI element is rendered/available
  async waitForElement(selector, timeout = 50, maxRetries = 5) {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      const checkElement = () => {
        const element = document.querySelector(selector); // Check if element exists
        if (element) {
          resolve(element); // Element is rendered, do return
        } else if (attempts < maxRetries) {
          attempts++;
          setTimeout(checkElement, timeout); // Wait and check again
        } else {
          reject(
            new Error(
              `Element with selector "${selector}" wasn't found after ${maxRetries} attempts.`
            )
          );
        }
      };
      checkElement(); // Do the check
    });
  }


  async custOpenLocationLookup(evt) {
    let DS;
    let locationDialog;
    let custLookup;

    if (evt.page.name === "createwo") {
      DS = evt.app.findDatasource("dsCreateWo")
      locationDialog = "custOpenCreadWOLocationLookupCreate"
      custLookup = "custJlocationLookupDSCreate"
    }
    if (evt.page.name === "woedit") {
      DS = evt.app.findDatasource("dsWoedit");
      locationDialog = "custOpenCreadWOLocationLookup"
      custLookup = "custJlocationLookupDS"
    }

    //Custom json-datasource
    let custjLoc = evt.app.findDatasource(custLookup);
    //Clear and reset
    custjLoc.clearState();
    custjLoc.resetState();
    //Show dialog
    evt.page.showDialog(locationDialog);
    //Check actual location value, if no location-value to filter with don't fetch any values
    if (DS.item) {
      const locval = DS.item.locationnum ? DS.item.locationnum : DS.item.location;
      if (locval && locval !== "") {
        const locDS = evt.app.findDatasource("locationLookupDS");
        if (locDS) {
          //Set state loading to visualize the loading indicator for end user
          custjLoc.state.loading = true;
          //Remove any previous filter on locationLookupDS
          locDS.clearState();
          locDS.resetState();
          await locDS.initializeQbe();
          //If mobile use %value% syntax, otherwise (web/pc) value% syntax works.
          if (Device.get().isMaximoMobile)
            locDS.setQBE("location", "%" + locval + "%");
          else
            locDS.setQBE("location", locval + "%");

          //let locitems = await locDS.searchQBE();
          //Use load with pageSize otherwise limited to 100
          let locitems = await locDS.load({ pageSize: 4000 });
          let selectedItem;
          let tempArr = [];
          locitems.forEach((item) => {
            if (item.location === locval) {
              selectedItem = item;
            }
            //If Mobile device, validate that location starts with the correct value to get rid of those that not qualify for value%-syntax
            if (Device.get().isMaximoMobile) {
              if (item.location.startsWith(locval))
                tempArr.push(item);
            }
            else
              tempArr.push(item);
          });

          locitems = tempArr;

          //Load data to custom json-datasource
          await custjLoc.load({ src: locitems, noCache: true });
          if (selectedItem) {
            custjLoc.setSelectedItem(selectedItem, true);
          }
          //Reset filter on standard datasource locationLookupDS
          locDS.clearState();
          locDS.resetState();
        }
      }
    }
  }
  async pageResumed(page, app) {
    this.app = app;
    this.page = page;

    if (page.name === "custListReportedHours") {
      let event = {};
      event.selectedItem = { id: page.state.timeFrame };
      await this.loadReportedHours(event);
      await this.selectDayWithReportedHours();
    }

    /*//if (Device.get().isMaximoMobile) {
    if (page.name === "relatedWorkOrder") {
          let relDS = this.app.findDatasource("relatedrectkt");
          await relDS.forceReload();
    }
    //}*/

    /* IT03007617 - Validate session on Mobile
    *  Specific for 8.8 and can be removed in future versions.
    *  To make sure that user gets information if session has exceed the time limit and is invalid
    */
    if (Device.get().isMaximoMobile)
      this.validateSession();
  }

  async pageInitialized(page) {
    if (page.name === 'relatedWorkOrder') {
      let ctrl = page.controllers[0];
      let oldpageResumed = ctrl.pageResumed.bind(ctrl);
      ctrl.pageResumed = async(evt) => {
        //'evt'is the parameter that would have been passed to the original pageResumed
        await oldpageResumed(evt);
        //after, if followup with response send feedback to user and clear incomingContext
        const incomingContext = this.app && this.app.state && this.app.state.incomingContext;
        if (incomingContext && incomingContext.followuptk) {
          this.app.toast(incomingContext.label, 'success');
          this.app.state.incomingContext = {};
        }
      }
    } else if (page.name === 'report_work') {
      this.premiumPayCode(page);
      this.pageInitReportwork(page);

    } else if (page.name === "workOrderDetails") {
      let c = page.controllers[0];
      let oldpageResumed = c.pageResumed.bind(c);
      c.pageResumed = async (evt, app) => {
        await oldpageResumed(evt, app);
        const woDetailResource = evt.datasources["woDetailResource"];

        if (woDetailResource.item.schedstart) {
          await this.setLocaleTime("schedstart", woDetailResource);
        }
        if (woDetailResource.item.schedfinish) {
          await this.setLocaleTime("schedfinish", woDetailResource);
        }
        if (woDetailResource.item.reportdate) {
          await this.setLocaleTime("reportdate", woDetailResource);
        }
      };

      c.saveUpdateMeterDialogDetail = async () => {
        this.updatedsaveUpdateMeterDialogDetail(c);
      }

    } else if (page.name === "createwo") {
      let c = page.controllers[0];
      let oldCreateWorkorder = c.createWorkorder.bind(c);
      c.createWorkorder = (evt) => {
        oldCreateWorkorder(evt);
        if (evt.item) {
          c.page.state.workactivity = "";
          c.page.state.crewid = "";
        }
      }
    } else if (page.name === 'failureDetails') {
      this.pageInitFailureDetails(page);
    }
    else if (page.name === "woedit") {
      //IT02959244 - Automatically select NO if GL-question is asked
      //This logic is executed for MOBILE only
      if (Device.get().isMaximoMobile) {
        let oldshowDialog = page.showDialog.bind(page);
        page.showDialog = (name) => {
          oldshowDialog(name);
          if (
            name === "sysMsgDialog_" + page.name &&
            !page.params.followup &&
            (this.page.state.selectedItem.action === "SETLOCGL" ||
              this.page.state.selectedItem.action === "SETASSETGL")
          ) {
            this.waitForElement(
              "#sysMsgDialog_" +
              page.name +
              "_button_group_sysMsgDialog_" +
              page.name +
              "_secondary_button",
              50,
              5
            )
              .then((element) => {
                element.click();
              })
              .catch((error) => {
                console.error(error.message);
              });
          }
        };
      }
    }
    else if (page.name === "tasks") {
      let ctrl = page.controllers[0];
      let oldcompleteWoTask = ctrl.completeWoTask.bind(ctrl);

      ctrl.completeWoTask = async (task) => {
        localStorage.setItem(`${page.name}scrollpos`, window.scrollY);
        await oldcompleteWoTask(task);
        await this.getScrollPosition(page.name);
      };
    } else if (page.name === "schedule") {
      let c = page.controllers[0];
      c.saveUpdateMeterDialog = async () => {
        this.updatedsaveUpdateMeterDialogDetail(c);
      }

      //IT02984882 - Set scrollposition in localstorage before calling showWODetail..
      //and get the scrollposition after returning
      let oldshowWODetail = c.showWODetail.bind(c);
      let oldpageResumed = c.pageResumed.bind(c);

      c.showWODetail = (item) => {
        localStorage.setItem(`${page.name}scrollpos`, window.scrollY);
        oldshowWODetail(item)
      }
      c.pageResumed = async (page) => {
        await oldpageResumed(page);
        await this.getScrollPosition(page.name);
      }
    } else if (page.name === "custListReportedHours") {
      this.app.state.pageLoading = true;
      page.state.timeFrame = "thisWeek";
      let event = {};
      event.selectedItem = { id: "thisWeek" };
      this.loadReportedHours(event);
    } 
  }
  /*
    ********** PAGE report_work **********
    */
  pageInitReportwork(page) {
    let reportCtrl = page.controllers[0];
    let oldsaveLaborTransaction = reportCtrl.saveLaborTransaction.bind(reportCtrl);
    reportCtrl.saveLaborTransaction = async (evt) => {
      await this.custSaveLaborTransaction(evt);
    }
  }
  async custSaveLaborTransaction(evt) {
    this.page.state.useConfirmDialog = false;
    let ctrl = evt.page.controllers[0];
    let personInfo = evt.app.client.userInfo;
    let laborcode = evt.page.state.laborCode || personInfo.labor.laborcode;
    let siteID = personInfo.insertSite;
    let dataFormatter = evt.app.dataFormatter;
    let craft = ''; let skilllevel = ''; let startDate; let rate = 0;

    let labords = evt.page.datasources['reportworkLaborDetailds'];
    let reportworkLaborList = evt.page.datasources["reportworkLaborDetailds"];

    let WoDetailPageDs = evt.app.findDatasource('woDetailResource');
    const schPage = evt.app.findPage("schedule") || evt.app.findPage("approvals");
    let WoListPageDs = evt.app.findDatasource(schPage.state.selectedDS);

    // istanbul ignore if
    if (ctrl.validateEndDateTime(evt)) {
      return;
    }

    craft = evt.page.state.craft;
    skilllevel = evt.page.state.skilllevel ? evt.page.state.skilllevel : '';
    rate = evt.page.state.rate || undefined;
    // istanbul ignore next
    if (evt.page.state.errorMessage) {
      return;
    }

    // istanbul ignore next
    if (labords.item["startdate"]) {
      startDate = dataFormatter.dateWithoutTimeZone(labords.item["startdate"]);
    }

    const startTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["starttime"]));
    const finishTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["finishtime"]));

    // istanbul ignore next
    if (evt.page.state.action === 'add') {
      let labor = {
        craft: craft,
        laborcode: laborcode,
        transtype: labords.item["transtype"],
        transtype_description: labords.item["transtype_description"],
        skilllevel: skilllevel,
        regularhrs: labords.item["regularhrs"],
        startdate: startDate,
        starttime: startTime,
        finishdate: dataFormatter.dateWithoutTimeZone(labords.item["finishdate"]),
        finishtime: finishTime,
        siteid: siteID,
        payrate: rate,
        craftdescription: labords.item.craftdescription,
        displayname: labords.item.displayname,
        taskid: labords.item.taskid,
        actualtaskid: labords.item.actualtaskid,
        task_description: labords.item.task_description,
        memo: labords.item.memo,
        premiumpayhours: labords.item.premiumpayhours,
        premiumpaycode: labords.item.premiumpaycode
      };

      // istanbul ignore next
      let option = {
        responseProperties: 'labtransid, anywhererefid'
      }

      try {
        this.page.state.useConfirmDialog = false;
        evt.page.state.loadinglabor = true;
        ctrl.saveDataSuccessful = true;
        labords.on('put-data-failed', ctrl.onSaveDataFailed.bind(ctrl));
        await labords.put(labor, option);
      }
      catch (err) {
        //handle error
      }
      finally {
        this.page.state.useConfirmDialog = false;
        evt.page.state.loadinglabor = false;
        ctrl.saveDataSuccessful = true;
        labords.off('put-data-failed', ctrl.onSaveDataFailed.bind(ctrl));
      }
    } else {
      let labor = {
        craft: craft,
        regularhrs: labords.item["regularhrs"],
        startdate: startDate,
        starttime: startTime,
        finishdate: dataFormatter.dateWithoutTimeZone(labords.item["finishdate"]),
        finishtime: finishTime,
        laborcode: laborcode || labords.item["laborcode"],
        skilllevel: skilllevel,
        siteid: siteID,
        transtype: labords.item["transtype"],
        transtype_description: labords.item["transtype_description"],
        labtransid: labords.item["labtransid"],
        payrate: rate,
        href: labords.item["href"],
        anywhererefid: labords.item["anywhererefid"],
        craftdescription: labords.item.craftdescription,
        displayname: labords.item.displayname,
        taskid: labords.item.taskid,
        actualtaskid: labords.item.actualtaskid,
        task_description: labords.item.task_description
      };

      if ((labords.item["timerstatus_maxvalue"] === 'ACTIVE' || labords.item["timerstatus_maxvalue"] === 'COMPLETE') && evt.page.state.timerStatusComplete) {
        if ((labor.finishdate || labor.finishtime) || (labor.startdate && labor.starttime && labor.regularhrs && labor.regularhrs > 0)) {
          labor.timerstatus = evt.page.state.timerStatusComplete.value;
          labor.timerstatus_maxvalue = evt.page.state.timerStatusComplete.maxvalue;
        }
      }

      let option = {
        responseProperties: 'labtransid, anywhererefid'
      }

      try {
        this.page.state.useConfirmDialog = false;
        evt.page.state.loadinglabor = true;
        ctrl.saveDataSuccessful = true;
        labords.on('update-data-failed', ctrl.onSaveDataFailed.bind(ctrl));
        await labords.update(labor, option);
      }
      catch (err) {
        //handle error
      }
      finally {
        this.page.state.useConfirmDialog = false;
        evt.page.state.loadinglabor = false;
        ctrl.saveDataSuccessful = true;
        labords.off('update-data-failed', ctrl.onSaveDataFailed.bind(ctrl));

      }
    }

    // istanbul ignore next
    evt.page.findDialog("reportTimeDrawer").closeDialog();
    evt.page.findDialog("reportTimeDrawerPremium").closeDialog();

    try {
      evt.page.state.loadinglabor = true;
      // istanbul ignore if
      if (Device.get().isMaximoMobile) {
        if (WoDetailPageDs) {
          await WoDetailPageDs.forceReload();
        }
        await evt.page.findDatasource('woDetailsReportWork').forceReload();
        await WoListPageDs.forceReload();
      }
      await reportworkLaborList.forceReload();
    } finally {
      evt.page.state.loadinglabor = false;
    }
  }
  async showWOChilds(item) {
    if (item.wonum) {
      if (!this.page.state.isChildView) {
        let wonum = item.wonum;
        let siteid = item.siteid;
        this.page.state.isChildView = true;
        if (!this.app.state.custParentItem) {
          this.app.state.custPrevSelectedDS = this.page.state.selectedDS;
        }
        this.page.state.selectedDS = "custSubWODS";
        this.app.state.custParentItem = item;
        const childDs = this.app.findDatasource("custSubWODS");
        if (childDs) {
          childDs.clearState();
          childDs.resetState();
          console.log(childDs);
          this.page.state.woItems = undefined;
          childDs.initializeQbe();
          childDs.setQBE("parent", "=", wonum);
          childDs.setQBE("siteid", "=", siteid);
          this.page.state.woItems = await childDs.searchQBE();
        }
      }
    }
  }
  /*
  * Function to move back from child work order view to previous query-selection
  */
  async moveToMainList() {
    this.page.state.selectedDS = this.app.state.custPrevSelectedDS;
    this.app.state.custPrevSelectedDS = undefined;
    this.page.state.isChildView = false;
    this.app.state.custParentItem = undefined;
    this.page.state.woItems = await this.page.datasources[this.page.state.selectedDS]?.forceReload();
    await this.getScrollPosition(this.page.name);
  }
  /*
   * Function to display the local timezone
   */
  async setLocaleTime(date_value, ds) {
    const localeString = new Date(`${ds.item[date_value]}`).toString();

    const new_date_value =
      this.app.dataFormatter.convertDatetoISO(localeString);

    ds.item[date_value] = new_date_value;
  }
  /*
  As the parent schedule page gets lost when switching between technician and SR apps, we use this to set current page to schedule
  and call the showWOChilds method with our custParentItem state to once again render our childView
  */
  async navigateBackToChildWOs() {
    this.app.setCurrentPage({
      name: "schedule",
      resetScroll: true,
      params: {
      },
    });
    this.page.state.isChildView = false; //to ensure showWOChilds executes correctly
    await this.showWOChilds(this.app.state.custParentItem);
  }
  /**
   * Function to open WorkType lookup
   */
  openWorkActivityLookup = async (evt) => {
    let alndomainDs = this.app.findDatasource("workActivityLookupDs");
    //await alndomainDs.initializeQbe();
    //await alndomainDs.setQBE("DOMAINID", "=", "XWRKACTIVITY");
    //await alndomainDs.searchQBE();
    let selectedItem;
    alndomainDs.items.forEach(item => {
      // istanbul ignore next
      if (item.xworkactivity === evt.page.state.workactivity) {
        selectedItem = item;
      }
    });
    if (selectedItem) {
      alndomainDs.setSelectedItem(selectedItem, true);
    }
    if (evt.is_edit) {
      evt.page.showDialog("workActivityLookup");
    }
    else {
      evt.page.showDialog("workActLookup");
    }
    evt.page.state.dialogOpened = true;
  }

  /**
   * Function to select Work Activity
   */
  selectWorkActivity = (evt) => {
    // istanbul ignore else
    if (evt) {
      if (evt.is_edit) {
        evt.page.datasources.dsWoedit.item["xworkactivity"] = evt.value;
      } else {
        evt.page.datasources.dsCreateWo.item["xworkactivity"] = evt.value;
      }
      evt.page.state.workactivity = evt.value;
    }
  }
  /**
 * Function to open Crew lookup
 */
  openCrewLookup = async (evt) => {
    let alndomainDs = this.app.findDatasource("crewLookupDs");
    //await alndomainDs.initializeQbe();
    //await alndomainDs.setQBE("DOMAINID", "=", "CREWID");
    //await alndomainDs.searchQBE();
    let selectedItem;
    alndomainDs.items.forEach(item => {
      // istanbul ignore next
      if (item.crewid === evt.page.state.crewid) {
        selectedItem = item;
      }
    });
    if (selectedItem) {
      alndomainDs.setSelectedItem(selectedItem, true);
    }
    if (evt.is_edit) {
      evt.page.showDialog("crewLookup");
    }
    else {
      evt.page.showDialog("lookupCrew");
    }
    evt.page.state.dialogOpened = true;
  }

  /**
   * Function to select Crew
   */
  selectCrew = (evt) => {
    // istanbul ignore else
    if (evt) {
      if (evt.is_edit) {
        evt.page.datasources.dsWoedit.item["crewid"] = evt.value;
      } else {
        evt.page.datasources.dsCreateWo.item["crewid"] = evt.value;
      }
      evt.page.state.crewid = evt.value;
    }
  }
  replaceSpecialCharacters(inputString) {
    var regex = /[ÿáàâãäåéèêëíîïóôöúüñçǽȳḧ]/g;
    var replacedString = inputString.replace(regex, "%");
    return replacedString;
  }
  async setSearchTextToOriginal(datasourceName, originalSearchText) {
    const ds = await this.app.findDatasource(datasourceName);
    this.page.state.setSearchTextToOriginal = true;
    await ds.load({ pageSize: ds.lastQuery.pageSize, size: ds.lastQuery.size, start: ds.lastQuery.start })
    this.page.state.setSearchTextToOriginal = undefined;
    ds.state.currentSearch = originalSearchText;
  }


  /* IT03007617 - Validate session on Mobile
  *  Specific for 8.8 and can be removed in future versions.
  *  To make sure that user gets information if session has exceed the time limit and is invalid
  */
  async validateSession() {
    let firstLoginData = Browser.get().loadJSON('FirstLoginData', false);
    if (firstLoginData) {
      let d = new Date();
      let loginDate = this.app.dataFormatter.convertISOtoDate(firstLoginData.date);
      if (d && loginDate) {
        let hours = Math.abs(loginDate - d) / 36e5;
        //Only check session after 6 hours and when device has network available
        if (hours > 6 && this.app.state.networkConnected) {
          const rc = this.app.client.restclient;
          await rc.get('/whoami')
            .then((response) => {
              console.log("All is good..");
            })
            .catch((error) => {
              let sysMsg = this.app.getLocalizedLabel('custom_invalid_session_msg', 'Your previous session has been active for too long and has been deactivated due to security measures. Please re-login to make sure that you have a valid session. If this message is present after re-login, please contact the system administrator.')
              let uiManager = this.app.userInteractionManager;
              uiManager.error(sysMsg);
            });
        }
      }
    }
  }

  /**
   * LOCATION DRILLDOWN SECTION START
   */

  async custOpenDrillLocationLookup() {
    if (this.page.findDialog('custWODrillLocLookup')) {
      this.page.state.drillDownParent = null;
      this.page.showDialog('custWODrillLocLookup');
      const classification = "PLANT";
      const locsystemid = "PRIMARY";
      let dsWoEdit = this.app.findDatasource("dsWoedit");
      const woloc = dsWoEdit.item.locationnum;
      let woorgid = dsWoEdit.item.orgid;

      let ds = this.app.findDatasource("locationLookupDS");
      ds.clearState();
      ds.resetState();
      //ADD CHECK IF LOCATION IS EMPTY
      if (woloc) {
        let locArray = [];
        await ds.initializeQbe();
        ds.setQBE("location", "=", woloc);
        ds.setQBE("orgid", "=", woorgid);
        await ds.searchQBE();
        let actLoc = ds.items[0];
        let doDrill = true;

        if (actLoc) {
          if (actLoc.classification === classification) {
            let level1 = {
              "location": woloc,
              "systemid": locsystemid
            };
            await this.custDrillInLocation(level1);
            doDrill = false;
          }
          else {
            if (!actLoc.parent) {
              let level1 = {
                "location": woloc,
                "systemid": locsystemid
              };
              await this.custDrillInLocation(level1);
              doDrill = false;
            }
            else {
              locArray.push({ "location": actLoc.location, "childcount": actLoc.childcount });
              let topLevelFound = false;
              let firstIteration = true;
              let tempParent;
              while (!topLevelFound) {
                let locParent;
                if (firstIteration) {
                  locParent = await this.getLocAncestors(actLoc);
                  firstIteration = false;
                }
                else {
                  locParent = await this.getLocAncestors(tempParent);
                }

                if (locParent) {
                  if (locParent.classification === classification) {
                    locArray.push({ "location": locParent.location, "childcount": locParent.childcount });
                    let lastParent = await this.getLocAncestors(locParent);
                    locArray.push({ "location": lastParent.location, "childcount": lastParent.childcount });
                    topLevelFound = true;
                  }
                  else {
                    if (!locParent.parent) {
                      locArray.push({ "location": locParent.location, "childcount": locParent.childcount });
                      topLevelFound = true;
                    }
                    else {
                      locArray.push({ "location": locParent.location, "childcount": locParent.childcount });
                      tempParent = locParent;
                    }
                  }
                }
                else {
                  topLevelFound = true;
                }
              }
            }
          }
        }

        if (doDrill) {
          if (locArray.length === 0) {
            let ds = this.app.findDatasource("locationLookupDS");
            await ds.initializeQbe();
            ds.setQBE("location", "=", "null");
            await ds.searchQBE();
          }
          else {
            if (locArray.length === 1) {
              let item = {
                "parent": woloc,
                "systemid": locsystemid
              };
              await this.custDrillInLocation(item)
            }
            else {
              let locCount = locArray.length - 1;
              console.log("*** locCount: " + locCount + " ****");
              let item = {
                "location": locArray[locArray.length - 1].location,
                "systemid": locsystemid
              };
              console.log("*** item: " + item.location + " ****");
              this.page.state.drillDownParent = item;
              await this.custDrillInLocation(item);

              locCount--;
              while (locCount >= 0) {
                let locDs = this.app.findDatasource("locationLookupDS");
                if (!this.page.state.waitForChild) {
                  if (locCount > 0 || (locCount === 0 && locArray[locCount].childcount > 0)) {
                    //Wait until element for Location selection is available in UI. max 30 tries.
                    this.navigateChildNode(locArray[locCount].location, 150, 30)
                      .then((element) => {
                        this.page.state.waitForChild = true;
                        element.click();
                      })
                      .catch((error) => {
                        console.error(error.message);
                      });
                  }

                  locCount--;
                }
              }
            }
          }
        }
      }
      else {
        await ds.initializeQbe();
        ds.setQBE("location", "=", "null");
        ds.setQBE("orgid", "=", woorgid);
        await ds.searchQBE();
      }
    }
    else {
      console.log("*** Dialog custWODrillLocLookup can't be found! ****");
    }
  }

  async getLocAncestors(item) {
    let ds = this.app.findDatasource("locationLookupDS");
    await ds.initializeQbe();
    ds.setQBE("location", "=", item.parent);
    ds.setQBE("siteid", "=", item.siteid);
    await ds.searchQBE();
    return ds.items[0]
  }

  //Custom function to wait until specific UI element is rendered/available
  async navigateChildNode(targetText, timeout = 50, maxRetries = 5) {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      const checkElementText = () => {
        const paragraphs = document.querySelectorAll("p"); // Check if element exists
        const targetParagraph = Array.from(paragraphs).find(p => p.textContent.trim() === targetText);
        if (targetParagraph) {
          let li = targetParagraph.closest("li");
          if (li) {
            let itemBtn = li.querySelector(".mx--datalist-select-btn");
            if (itemBtn) {
              resolve(itemBtn); // Element is rendered, do return
            }
          }

        } else if (attempts < maxRetries) {
          attempts++;
          setTimeout(checkElementText, timeout); // Wait and check again
        } else {
          reject(new Error(`Element with targetText "${targetText}" wasn't found after ${maxRetries} attempts.`));
        }
      };
      checkElementText(); // Do the check
    });
  }

  async custDrillInLocation(item) {
    if (item || (!item && this.page.state.drillDownParent)) {
      if (!item && this.page.state.drillDownParent)
        item = this.page.state.drillDownParent;

      let ds = this.app.findDatasource("locationLookupDS");
      await ds.initializeQbe();
      if (ds.lastQuery) {
        ds.lastQuery.searchText = ""; //Clear text search on-drill-in
      }
      if (Device.get().isMaximoMobile) {
        if (item) {
          ds.setQBE("parent", "=", item.location);
          ds.setQBE("primarysystem", true);
          ds.setQBE("systemid", "=", item.systemid);
        } else {
          ds.setQBE("parent", "!=", "*");
          ds.setQBE("primarysystem", true);
        }
      } else {
        if (item) {
          ds.setQBE("LOCHIERLOCONLY.parent", "=", item.location);
          ds.setQBE("LOCHIERLOCONLY.LOCSYSTEM.primarysystem", "=true");
        } else {
          ds.setQBE("LOCHIERLOCONLY.parent", "=", "null");
          ds.setQBE("LOCHIERLOCONLY.LOCSYSTEM.primarysystem", "=true");
        }
      }
      await ds.searchQBE();
      if (this.page.state.waitForChild)
        this.page.state.waitForChild = false;
    }
  }

  async custDrillChooseLocation(item) {
    this.page.findDialog("custWODrillLocLookup").closeDialog();
    const ctrl = this.page.controllers[0];
    ctrl.chooseLocation(item);
    let ds = this.app.findDatasource("locationLookupDS");
    if (ds) {
      ds.clearState();
      ds.resetState();
    }

  }
  //Close drilldown dialog
  closeWODrillLocLookup() {
    let ds = this.app.findDatasource("locationLookupDS");
    if (ds) {
      ds.clearState();
      ds.resetState();
    }
  }

  /*
  * LOCATION DRILLDOWN SECTION END
  */


  /* Premiim code functionality*/
  premiumPayCode(page) {
    let c = page.controllers[0];

    /**
     * Function to select premium pay code
     */
    c.selectPremiumpaycode = (evt) => {
      let labords = page.datasources['reportworkLaborDetailds'];
      labords.item["premiumpaycode_description"] = evt.premiumpaycode_description;
      labords.item["premiumpaycode"] = evt.premiumpaycode;
      page.state.useConfirmDialog = true;
    }
    /**
     * Function to open custom report time drawer for premium pay hours
     */
    c.openReportTimeDrawerPremium = async (evt) => {
      page.state.useConfirmDialog = false;
      page.state.callMethodAction = 'LABOR';
      let personInfo = this.app.client.userInfo;
      let craft = personInfo.labor.laborcraftrate.craft;
      page.state.disableButton = false;
      let dataFormatter = this.app.dataFormatter;
      let device = Device.get();
      let laborCode = personInfo.labor.laborcode;
      let laborCodeDesc = personInfo.displayName || laborCode;
      page.state.laborCode = laborCode;
      page.state.selectedTaskItem = undefined;

      //reset labor and craftrate lookup datasources
      /*let laborLookupDs = this.app.findDatasource('laborDs');
      laborLookupDs.clearState();
      laborLookupDs.load();
 
      let craftrateLookupDs = this.app.findDatasource('craftrate');
      craftrateLookupDs.clearState();
      craftrateLookupDs.load();*/

      //Set default craft skill
      await c.setCraftSkill();

      //Fetch the tasks
      await c.getWoTasks();
      craft = page.state.craft;

      // istanbul ignore else
      if (page.state.craftdata && page.state.craftdata.laborcode !== personInfo.labor.laborcode) {
        await c.openCraftSkillLookup({ page: page, app: this.app, openLookup: false });
      }
      let craftSkillLevel = page.state.craftdata;
      page.state.dateTimeRemoved = undefined;
      const labords = page.datasources['reportworkLaborDetailds'];
      let synonymdomainData = this.app.datasources['synonymdomainData'];
      page.state.timerStatusComplete = await SynonymUtil.getSynonym(synonymdomainData, 'TIMERSTATUS', 'TIMERSTATUS|COMPLETE');
      page.state.action = 'add';
      if (page.datasources['reportworkLaborDetailds']) {
        let labords = page.datasources['reportworkLaborDetailds'];
        let newLabtrans = await labords.addNew();
        if (device.isMaximoMobile) {
          c.updateSchema(labords);
        }
        if (this.app.state.networkConnected && newLabtrans) {
          labords.item["labtransid"] = newLabtrans.labtransid;
        }
        labords.item["transtype"] = newLabtrans && newLabtrans.transtype ? newLabtrans.transtype : await SynonymUtil.getDefaultExternalSynonymValue(synonymdomainData, 'LTTYPE', 'WORK');
        labords.item["transtype_description"] = newLabtrans && newLabtrans.transtype_description ? newLabtrans.transtype_description : this.app.getLocalizedLabel('defaultWorkType', 'Actual work time');
        labords.item["startdate"] = newLabtrans && newLabtrans.startdate ? newLabtrans.startdate : dataFormatter.parseDate(new Date());
        labords.item["regularhrs"] = 0;
        labords.item["starttime"] = null;
        labords.item["finishdate"] = '';
        labords.item["finishtime"] = null;
        labords.item["craftdescription"] = craftSkillLevel.craftdescription;
        labords.item["displayname"] = laborCodeDesc;
        labords.item["laborcode"] = laborCode;
        labords.item["premiumpayhours"] = newLabtrans && newLabtrans.premiumpayhours ? newLabtrans.premiumpayhours : 0;
        labords.item["premiumpaycode"] = newLabtrans && newLabtrans.premiumpaycode ? newLabtrans.premiumpaycode : null;
        if (craftSkillLevel) {
          page.state.craft = craftSkillLevel.craft;
          page.state.skilllevel = craftSkillLevel.skillleveldata;
          page.state.rate = craftSkillLevel.rate;
        }
      }

      page.state.transTypeValue = labords.item["transtype"];
      page.state.transTypeDesc = labords.item["transtype_description"];
      page.showDialog("reportTimeDrawerPremium");
      page.state.fieldChangedManually = false;
      page.state.useConfirmDialog = false;
    }

    /**
     * Validate that end time is not in future
     */
    c.validateEndDateTime = (evt) => {
      let labords = evt.page.datasources['reportworkLaborDetailds'];
      let dataFormatter = evt.app.dataFormatter;
      let invalidDatetime = false;

      let premiumpayhours = labords.item["premiumpayhours"] ? labords.item["premiumpayhours"] : 0;

      if (labords.item["startdate"] && labords.item["starttime"] && labords.item["regularhrs"] &&
        labords.item["regularhrs"] + premiumpayhours > 0 && evt.page.state.dateTimeRemoved) {
        let todayDate = new Date();
        let labtranstolerance = evt.page.datasources['woDetailsReportWork'].item["labtranstolerance"];
        todayDate = dataFormatter.convertISOtoDate(todayDate.setHours(todayDate.getHours() + dataFormatter.timeToDecimal(labtranstolerance)));

        let finishDate = c.calculateLaborDateTime(labords.item["startdate"], labords.item["starttime"], labords.item["regularhrs"] + premiumhours, false, evt.app);
        let finishTime = dataFormatter.dateWithoutTimeZone(dataFormatter.convertDatetoISO(c.combineDateTime(todayDate, finishDate, evt.app)));

        let laborFinishDateTime = c.combineDateTime(finishDate, finishTime, evt.app);

        // istanbul ignore if
        if ((dataFormatter.convertISOtoDate(c.getOnlyDatePart(finishDate, evt.app)) > todayDate) ||
          (c.getOnlyDatePart(finishDate, evt.app) === WOTimerUtil.removeSecondsFromTimeString(c.getOnlyDatePart(todayDate, evt.app)) &&
            (c.getMinutes(laborFinishDateTime, evt.app) > c.getMinutes(todayDate, evt.app)))) {
          let errorMessage = evt.app.getLocalizedLabel('regularhr_with_futuredate_msg', 'Actual labor can not be with future dates and times');
          c.showLaborWarnings(evt, 'regularhrs', errorMessage);
          invalidDatetime = true;
        }
      }

      return invalidDatetime;
    }

    /**
     * Function to save labor transactions, customized to include premium pay reporting
     */
    /*c.saveLaborTransaction = async (evt) => {
      page.state.useConfirmDialog=false;
      let personInfo = evt.app.client.userInfo;
      let laborcode = evt.page.state.laborCode || personInfo.labor.laborcode;
      let siteID = personInfo.insertSite;
      let dataFormatter = evt.app.dataFormatter;
      let craft = ''; let skilllevel = ''; let startDate; let rate = 0;
 
      let labords = evt.page.datasources['reportworkLaborDetailds'];
      let reportworkLaborList = evt.page.datasources["reportworkLabords"];
 
      let WoDetailPageDs = evt.app.findDatasource('woDetailResource');
      const schPage = evt.app.findPage("schedule") || evt.app.findPage("approvals");
      let WoListPageDs = evt.app.findDatasource(schPage.state.selectedDS);
 
      // istanbul ignore if
      if (c.validateEndDateTime(evt)) {
        return;
      }
 
      craft = evt.page.state.craft;
      skilllevel = evt.page.state.skilllevel ? evt.page.state.skilllevel : '';
      rate = evt.page.state.rate || undefined;
      // istanbul ignore next
      if (evt.page.state.errorMessage) {
        return;
      }
 
      // istanbul ignore next
      if (labords.item["startdate"]) {
        startDate = dataFormatter.dateWithoutTimeZone(labords.item["startdate"]);
      }
 
      const startTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["starttime"]));
      const finishTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["finishtime"]));
 
      // istanbul ignore next
      if (evt.page.state.action === 'add') {
        let labor = {
          craft: craft,
          laborcode: laborcode,
          transtype: labords.item["transtype"],
          transtype_description: labords.item["transtype_description"],
          skilllevel: skilllevel,
          regularhrs: labords.item["regularhrs"],
          startdate: startDate,
          starttime: startTime,
          finishdate: dataFormatter.dateWithoutTimeZone(labords.item["finishdate"]),
          finishtime: finishTime,
          siteid: siteID,
          payrate: rate,
          craftdescription: labords.item.craftdescription,
          displayname: labords.item.displayname,
          taskid: labords.item.taskid,
          actualtaskid: labords.item.actualtaskid,
          task_description:labords.item.task_description,
          premiumpayhours: labords.item.premiumpayhours,
          premiumpaycode: labords.item.premiumpaycode
        };
 
        // istanbul ignore next
        let option = {
          responseProperties: 'labtransid, anywhererefid'
        }
        const onDataFailedHandler = c.onSaveDataFailed.bind(c);
        try {
          page.state.useConfirmDialog = false;
          evt.page.state.loadinglabor = true;
          c.saveDataSuccessful = true;
          labords.on('put-data-failed', onDataFailedHandler);
          await labords.put(labor, option);
        }
        catch (err) {
          //handle error
        }
        finally {
          page.state.useConfirmDialog = false;
          evt.page.state.loadinglabor = false;
          c.saveDataSuccessful = true;
          labords.off('put-data-failed', onDataFailedHandler);
        }
      } else {
        let labor = {
          craft: craft,
          regularhrs: labords.item["regularhrs"],
          startdate: startDate,
          starttime: startTime,
          finishdate: dataFormatter.dateWithoutTimeZone(labords.item["finishdate"]),
          finishtime: finishTime,
          laborcode: laborcode || labords.item["laborcode"],
          skilllevel: skilllevel,
          siteid: siteID,
          transtype: labords.item["transtype"],
          transtype_description: labords.item["transtype_description"],
          labtransid: labords.item["labtransid"],
          payrate: rate,
          href: labords.item["href"],
          anywhererefid: labords.item["anywhererefid"],
          craftdescription: labords.item.craftdescription,
          displayname: labords.item.displayname,
          taskid: labords.item.taskid,
          actualtaskid: labords.item.actualtaskid,
          task_description:labords.item.task_description,
          premiumpayhours: labords.item.premiumpayhours,
          premiumpaycode: labords.item.premiumpaycode
        };
 
        if ((labords.item["timerstatus_maxvalue"] === 'ACTIVE' || labords.item["timerstatus_maxvalue"] === 'COMPLETE') && evt.page.state.timerStatusComplete) {
          if ((labor.finishdate || labor.finishtime) || (labor.startdate && labor.starttime && labor.regularhrs && labor.regularhrs > 0)) {
            labor.timerstatus = evt.page.state.timerStatusComplete.value;
            labor.timerstatus_maxvalue = evt.page.state.timerStatusComplete.maxvalue;
          }
        }
 
        let option = {
          responseProperties: 'labtransid, anywhererefid'
        }
        const onUpdateFailedHandler = c.onSaveDataFailed.bind(c);
        try {
          page.state.useConfirmDialog = false;
          evt.page.state.loadinglabor = true;
          c.saveDataSuccessful = true;
          labords.on('update-data-failed', onUpdateFailedHandler);
          await labords.update(labor, option);
        }
        catch (err) {
          //handle error
        }
        finally {
          page.state.useConfirmDialog = false;
          evt.page.state.loadinglabor = false;
          c.saveDataSuccessful = true;
          labords.off('update-data-failed', onUpdateFailedHandler);
 
        }
      }
 
      // istanbul ignore next
      evt.page.findDialog("reportTimeDrawer").closeDialog();
      evt.page.findDialog("reportTimeDrawerPremium").closeDialog();
      c.reloadLabor(evt, reportworkLaborList, WoListPageDs, WoDetailPageDs);
    }*/

    /**
     * Group the transactions on basis of labor, customized to include premium pay code and hours.
     */
    c.createGroupedLaborTransactions = (laborItems) => {
      let groupedItem = {
        labtransid: laborItems[0].labtransid,
        startdate: laborItems[0].startdate,
        starttime: laborItems[0].starttime,
        finishdate: laborItems[0].finishdate,
        finishtime: laborItems[0].finishtime,
        regularhrs: laborItems[0].regularhrs,
        transtype: laborItems[0].transtype,
        laborcode: laborItems[0].laborcode,
        anywhererefid: laborItems[0].anywhererefid,
        timerstatus: laborItems[0].timerstatus,
        displayname: laborItems[0].displayname || laborItems[0].laborcode,
        groupedlabor: laborItems,
        memo: laborItems[0].memo,
        premiumpayhours: laborItems[0].premiumpayhours,
        premiumpaycode: laborItems[0].premiumpaycode
      };

      return groupedItem;
    }

    /**
     * Function to validate regular hours and dates
     * Removed validations that automatically populate end time and end date
     */
    c.validateRegularHrs = (evt) => {
      let dataFormatter = evt.app.dataFormatter;
      let labords = evt.page.datasources['reportworkLaborDetailds'];
      let labtranstolerance = evt.page.datasources['woDetailsReportWork'].item["labtranstolerance"];
      /**
     * Getting the labtranstolerance value when WO created in offline mode
     */
      if (!labtranstolerance) {
        labtranstolerance = evt.app
          .findDatasource("defaultSetDs")
          .items[0].maxvars.filter(
            (item) => item.varname === "LABTRANSTOLERANCE"
          )[0]?.varvalue;
      }
      let startDate = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["startdate"]));
      let startTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["starttime"]));
      //let finishDate = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["finishdate"]));
      //let finishTime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item["finishtime"]));
      //let regularHrs = labords.item["regularhrs"];
      let errorMessage = ''; let errorField = '';
      let todayDate = new Date();
      todayDate = dataFormatter.convertISOtoDate(todayDate.setHours(todayDate.getHours() + dataFormatter.timeToDecimal(labtranstolerance)));

      if (labords.item["startdate"] === '') {
        errorMessage = this.app.getLocalizedLabel('startdate_msg', 'Start date is required');
        errorField = 'startdate';
        c.showLaborWarnings(evt, errorField, errorMessage);
        page.state.disableButton = true;
        return errorMessage;
      } else {
        page.state.disableButton = false;
        c.clearWarnings(evt, 'startdate');
      }

      let premiumpayhours = labords.item["premiumpayhours"] ? labords.item["premiumpayhours"] : 0;
      // istanbul ignore else
      if (labords.item["regularhrs"] === '') {
        errorMessage = this.app.getLocalizedLabel('regularhr_req_msg', 'Regular hours is required');
        errorField = 'regularhrs';
        c.showLaborWarnings(evt, errorField, errorMessage);
        page.state.disableButton = true;
        return errorMessage;
      } else if (typeof labords.item["regularhrs"] === 'string') {
        errorMessage = this.app.getLocalizedLabel('regularhr_invalid_msg', 'Invalid regular hours');
        errorField = 'regularhrs';
        c.showLaborWarnings(evt, errorField, errorMessage);
        page.state.disableButton = true;
        return errorMessage;
      } else if ((labords.item["regularhrs"] + premiumpayhours) === 0) {
        page.state.disableButton = true;
      } else {
        c.clearWarnings(evt, 'regularhrs');
        page.state.disableButton = false;
      }



      let laborStartDateTime = '';
      //let laborFinishDateTime = '';
      //let isCalculatedFinishDate = false;

      // istanbul ignore if
      if (startDate) {
        if (dataFormatter.convertISOtoDate(startDate) > todayDate) {
          errorMessage = this.app.getLocalizedLabel('future_startdate_msg', 'Start date cannot be in the future');
          errorField = 'startdate';
          c.showLaborWarnings(evt, errorField, errorMessage);
          c.clearWarnings(evt, 'starttime');
          return errorMessage;
        } else {
          c.clearWarnings(evt, 'startdate');
        }
      }

      if (startDate && startTime) {
        laborStartDateTime = c.combineDateTime(startDate, startTime);

        // istanbul ignore if
        if (laborStartDateTime > todayDate) {
          if (c.getMinutes(laborStartDateTime) > c.getMinutes(todayDate)) {
            errorMessage = this.app.getLocalizedLabel('future_starttime_msg', 'Start time cannot be in the future');
            errorField = 'starttime';
            c.clearWarnings(evt, 'startdate');
            c.showLaborWarnings(evt, errorField, errorMessage);
            return errorMessage;
          }
        }
        else {
          c.clearWarnings(evt, 'startdate');
          c.clearWarnings(evt, 'starttime');
        }
      }

      return errorMessage;
    }
    /**
       * Function to open the labor time drawer
       */
    c.openReportTimeDrawer = async (evt) => {
      page.state.useConfirmDialog = false;
      page.state.callMethodAction = 'LABOR';
      let personInfo = this.app.client.userInfo;
      let craft = personInfo.labor.laborcraftrate.craft;
      page.state.disableButton = false;
      let dataFormatter = this.app.dataFormatter;
      let device = Device.get();
      let laborCode = personInfo.labor.laborcode;
      let laborCodeDesc = personInfo.displayName || laborCode;
      page.state.laborCode = laborCode;
      page.state.selectedTaskItem = undefined;

      //reset labor and craftrate lookup datasources
      //let laborLookupDs = this.app.findDatasource('laborDs');
      //laborLookupDs.clearState();
      //laborLookupDs.load();

      //let craftrateLookupDs = this.app.findDatasource('craftrate');
      //craftrateLookupDs.clearState();
      //craftrateLookupDs.load();

      //Set default craft skill
      await c.setCraftSkill();

      //Fetch the tasks
      await c.getWoTasks();
      craft = page.state.craft;

      // istanbul ignore else
      if (page.state.craftdata && page.state.craftdata.laborcode !== personInfo.labor.laborcode) {
        await c.openCraftSkillLookup({ page: page, app: this.app, openLookup: false });
      }
      let craftSkillLevel = page.state.craftdata;
      page.state.dateTimeRemoved = undefined;
      const labords = page.datasources['reportworkLaborDetailds'];
      let synonymdomainData = this.app.datasources['synonymdomainData'];
      page.state.timerStatusComplete = await SynonymUtil.getSynonym(synonymdomainData, 'TIMERSTATUS', 'TIMERSTATUS|COMPLETE');

      // istanbul ignore next
      if (evt && evt.action === 'update') {
        labords.item.finishdate = '';
        labords.item.finishtime = '';
        await labords.initializeQbe();
        if (device.isMaximoMobile) {
          labords.setQBE('anywhererefid', '=', evt.item.anywhererefid);
        } else {
          labords.setQBE('labtransid', '=', evt.item.labtransid);
        }
        await labords.searchQBE(undefined, true);

        labords.item.starttime = dataFormatter.dateWithoutTimeZone(WOTimerUtil.removeSecondsFromTimeString(labords.item.starttime));
        labords.item.finishdate = evt.item.finishdate || '';
        labords.item.finishtime = evt.item.finishtime;
        labords.item.timerstatus = evt.item.timerstatus;
        labords.item.timerstatus_maxvalue = evt.item.timerstatus_maxvalue;
        labords.item.anywhererefid = evt.item.anywhererefid;
        labords.item.craftdescription = craftSkillLevel.craftdescription;
        page.state.craft = craft;
        page.state.rate = labords.item.payrate;
        page.state.skilllevel = labords.item.skilllevel;
        let timerStatus = labords.item.timerstatus_maxvalue;

        //Set craft and skill to default when timer started 
        if ((timerStatus === 'ACTIVE' || timerStatus === 'COMPLETE') && !labords.item.craft) {
          labords.item.craftdescription = craftSkillLevel.craftdescription;
          page.state.craft = craftSkillLevel.craft;
          page.state.skilllevel = craftSkillLevel.skillleveldata;
          page.state.rate = craftSkillLevel.rate;
        }

        page.state.action = 'update';
        if (device.isMaximoMobile) {
          //updateSchema is a temporary workaround
          c.updateSchema(labords);
          let typeDs = page.datasources["reportworksSynonymData"];
          typeDs.items.forEach(item => {
            if (item.value === evt.item.transtype) {
              labords.item["transtype_description"] = item.description;
            }
          });
        }
      } else {
        page.state.action = 'add';
        if (page.datasources['reportworkLaborDetailds']) {
          let labords = page.datasources['reportworkLaborDetailds'];
          let newLabtrans = await labords.addNew();
          if (device.isMaximoMobile) {
            c.updateSchema(labords);
          }
          if (this.app.state.networkConnected && newLabtrans) {
            labords.item["labtransid"] = newLabtrans.labtransid;
          }

          labords.item["transtype"] = newLabtrans && newLabtrans.transtype ? newLabtrans.transtype : await SynonymUtil.getDefaultExternalSynonymValue(synonymdomainData, 'LTTYPE', 'WORK');
          labords.item["transtype_description"] = newLabtrans && newLabtrans.transtype_description ? newLabtrans.transtype_description : this.app.getLocalizedLabel('defaultWorkType', 'Actual work time');
          labords.item["startdate"] = newLabtrans && newLabtrans.startdate ? newLabtrans.startdate : dataFormatter.parseDate(new Date());
          labords.item["regularhrs"] = newLabtrans && newLabtrans.regularhrs ? newLabtrans.regularhrs : 0;
          labords.item["starttime"] = null;
          labords.item["finishdate"] = '';
          labords.item["finishtime"] = null;
          labords.item["craftdescription"] = craftSkillLevel.craftdescription;
          labords.item["displayname"] = laborCodeDesc;
          labords.item["laborcode"] = laborCode;

          if (craftSkillLevel) {
            page.state.craft = craftSkillLevel.craft;
            page.state.skilllevel = craftSkillLevel.skillleveldata;
            page.state.rate = craftSkillLevel.rate;
          }
        }
      }

      // istanbul ignore next 
      page.state.transTypeValue = labords.item["transtype"];
      page.state.transTypeDesc = labords.item["transtype_description"];
      page.showDialog("reportTimeDrawer");
      page.state.fieldChangedManually = false;
      // set all the values of datasource item before this line
      page.state.useConfirmDialog = false;
    }
  }
  onValueChanged({ datasource, item, field, oldValue, newValue }) {
    // When craft or labor is changed, premium pay code is restored
    if (datasource && datasource.name === "reportworkLaborDetailds" && (field === "displayname" || field === "craftdescription") && oldValue !== newValue) {
      item.premiumpaycode = "";
      item.premiumpaycode_description = "";
    }
  }
  /**
   * Open premiumpay lookup to select premiumpaycode
   */
  openPremiumpayLookup = async (evt) => {
    let craftrateDs = evt.page.datasources['craftrate'];
    let premiumpayDs = evt.page.datasources['jpremiumpayDs'];
    let personInfo = evt.app.client.userInfo;
    let craft = evt.page.state.craft;
    let laborcode = evt.page.state.laborCode;
    let skilllevel = evt.page.state.skilllevel;
    let selectedItem;
    await craftrateDs.initializeQbe();
    craftrateDs.setQBE('orgid', '=', personInfo.defaultOrg);
    craftrateDs.setQBE('craft', '=', craft);
    craftrateDs.setQBE('laborcode', '=', laborcode);

    if (skilllevel) {
      if (Device.get().isMaximoMobile) craftrateDs.setQBE('skillleveldata', '=', skilllevel);
      else craftrateDs.setQBE('skilllevel', '=', skilllevel);
    }
    await craftrateDs.searchQBE();
    let premiumpayArr = [...craftrateDs.item["ppcraftrate"]];
    await premiumpayDs.load({ src: premiumpayArr, noCache: true });
    await premiumpayDs.searchQBE();
    let currentPremiumPayCode = evt.page.datasources["reportworkLaborDetailds"].premiumpaycode;
    premiumpayDs.items.forEach(item => {
      if (item.premiumpaycode === currentPremiumPayCode) {
        selectedItem = item;
      }
    })
    if (selectedItem) {
      premiumpayDs.setSelectedItem(selectedItem, true);
    }
    evt.page.showDialog("premiumpayLookup");
  }

  // Method to retain the scroll position
  async getScrollPosition(pagename) {
  const scrollPosition = localStorage.getItem(`${pagename}scrollpos`)
 
  if (!scrollPosition || isNaN(scrollPosition)) return
 
  const maxAttempts = 100; // limit retries to avoid getting stuck in an endless loop, 100 attempts x 300ms will ensure we wont run it for longer than 30s
  const delay = (ms) => new Promise(res => setTimeout(res, ms));
 
  let attempts = 0;
  while (attempts < maxAttempts) {
    const scrollHeight = document.documentElement.scrollHeight;
    const clientHeight = window.innerHeight;
 
    if (scrollHeight - clientHeight >= scrollPosition) {
      window.scroll({top: scrollPosition, behavior: 'smooth'});
      localStorage.removeItem(`${pagename}scrollpos`);
      if(document.documentElement.scrollHeight >= scrollPosition) break;
    }
   
    await delay(300);
    // Trigger scrolling a bit to help auto-load more data
    window.scroll({top: scrollPosition, behavior: 'smooth'});
    attempts++;
  }
 
}


  /*
    Adjusted OOB method to fix the issue with reporting the same number on meters twice in a row
    adjusted to work when its called from both workOrderDetails page and schedule page
  */
  async updatedsaveUpdateMeterDialogDetail(c) {
    let item = this.app.findDatasource("woDetailds").item;
    //istanbul ignore else
    if (!this.isRollover) {
      let assetNumData =
        item.asset && item.asset.length > 0
          ? item.asset[0].assetnum
          : undefined;
      let locationData = item.locationnum ? item.locationnum : undefined;

      //Call save on button click
      let assetMeterDs = this.app.findDatasource("woassetmeters");
      let locationMeterDs = this.app.findDatasource("wolocationmeters");

      //istanbul ignore if
      if (this.page.state.oldReading) {
        (typeof c.validateMeterDateDetail === "function" && c.validateMeterDateDetail()) || c.validateMeterDate(); //call the correct method, these are different depending on if its..
        (typeof c.validateMeterTimeDetail === "function" && c.validateMeterTimeDetail()) || c.validateMeterTime(); //..called from page workOrderDetails or schedule
      }

      //istanbul ignore else
      if (
        !this.page.state.invalidDateTime &&
        !this.page.state.hasAnyReadingError
      ) {
        await this.saveMeterReadings(
          {},
          this.app,
          assetMeterDs,
          locationMeterDs,
          this.page,
          c
        );  //controller (c) added as parameter since this method usually calls methods from its controller using this. 
        this.validatemeter = false;
        await WOUtil.closeUpdateMeterDialog(
          this,
          this.page,
          assetNumData,
          locationData,
          item.siteid,
          this.page.name === "workOrderDetails" ? "update_meterReading_drawer_detail" : "update_meterReading_drawer", //call the correct dialog depending on if page is workOrderDetails or Schedule
          this.app
        );
      }
    } else if (this.isRollover) {
      this.page.showDialog(this.page.name === "workOrderDetails" ? "rollOverDialogDetail" : "rollOverDialog"); //call the correct dialog depending on if page is workOrderDetails or Schedule
      return;
    }
  }

  async saveMeterReadings(changeObj, app, assetMeterDs, locationMeterDs, page, ctrl) {
    try {
      app.userInteractionManager.drawerBusy(true);
      let dataFormatter = app.dataFormatter;
      if (
        assetMeterDs &&
        (assetMeterDs.name === "woassetmeters" ||
          assetMeterDs.name.includes("cds_tasklistMeterds.activeassetmeter") ||
          assetMeterDs.name.includes(
            "cds_woMultiAssetLocationds.activeassetmeter"
          ))
      ) {
        // istanbul ignore if
        if (assetMeterDs && assetMeterDs.items.length > 0) {
          for (let i = 0; i < assetMeterDs.items.length; i++) {
            let udpatedMeterObj = assetMeterDs.items[i];
            if (typeof udpatedMeterObj.newreading !== "undefined") {
              let newreadingDate = page.state.newReading
                ? udpatedMeterObj.computedMeterCurDate
                : assetMeterDs.item.computedMeterCurDate;
              let time = page.state.newReading
                ? udpatedMeterObj.computedMeterCurTime
                : assetMeterDs.item.computedMeterCurTime;

              if (page.state.oldReading) {
                if (
                  assetMeterDs.name.includes(
                    "cds_tasklistMeterds.activeassetmeter"
                  ) ||
                  assetMeterDs.name.includes(
                    "cds_tasklistMeterds.activelocationmeter"
                  )
                ) {
                  newreadingDate =
                    app.findDatasource("tasklistMeterds").item
                      .computedMeterCurDate;
                  time =
                    app.findDatasource("tasklistMeterds").item
                      .computedMeterCurTime;
                }
                if (
                  assetMeterDs.name.includes(
                    "cds_woMultiAssetLocationds.activeassetmeter"
                  ) ||
                  locationMeterDs.name.includes(
                    "cds_woMultiAssetLocationds.activelocationmeter"
                  )
                ) {
                  newreadingDate = app.findDatasource("woMultiAssetLocationds")
                    .item.computedMeterCurDate;
                  time = app.findDatasource("woMultiAssetLocationds").item
                    .computedMeterCurTime;
                }
              }

              newreadingDate = dataFormatter.dateWithoutTimeZone(
                dataFormatter.convertISOtoDate(newreadingDate)
              );
              time = time
                ? dataFormatter.dateWithoutTimeZone(
                  dataFormatter.convertISOtoDate(time)
                )
                : "";

              newreadingDate.setHours(time ? time.getHours() : 0);
              newreadingDate.setMinutes(time ? time.getMinutes() : 0);
              newreadingDate.setMilliseconds(0);
              newreadingDate.setSeconds(0);

              // istanbul ignore if
              if (page.state.rollOverData && udpatedMeterObj.rollover) {
                page.state.rollOverData.forEach((element, index) => {
                  if (
                    element.item.assetmeterid === udpatedMeterObj.assetmeterid
                  ) {
                    if (page.state.rollOverData[index].dorollover) {
                      udpatedMeterObj.dorollover = true;
                    } else if (!page.state.rollOverData[index].dorollover) {
                      udpatedMeterObj.newreading = udpatedMeterObj.lastreading;
                    }
                  }
                });
              }

              // istanbul ignore else
              if (
                udpatedMeterObj.newreading === 0 ||
                udpatedMeterObj.newreading
              ) {
                let newmeterreading = {
                  assetmeterid: udpatedMeterObj.assetmeterid,
                  assetnum: udpatedMeterObj.assetnum,
                  dorollover: udpatedMeterObj.dorollover
                    ? udpatedMeterObj.dorollover
                    : false,
                  inspector: app.client.userInfo.personid,
                  isdelta: false,
                  linearassetmeterid: 0,
                  metername: udpatedMeterObj.metername,
                  newreading: udpatedMeterObj.newreading,
                  newreadingdate: newreadingDate,
                  siteid: udpatedMeterObj.siteid,
                  href: udpatedMeterObj.href,
                };

                let option = {
                  responseProperties: "lastreading,newreading,newreadingdate",
                  localPayload: newmeterreading,
                  relationship: "activeassetmeter",
                  useRecordHref: true,
                  interactive: false,
                };

                let da = assetMeterDs.dataAdapter;
                da.options.query.interactive = 0;
                ctrl.saveDataSuccessful = true;

                assetMeterDs.on("put-data-failed", WOUtil.onSaveDataFailed);
                try {
                  let updatedResponse = await assetMeterDs.put(
                    newmeterreading,
                    option
                  );
                  // istanbul ignore next
                  if (updatedResponse && ctrl.saveDataSuccessful) {
                    assetMeterDs.items.forEach((element) => {
                      if (element.newreading) {
                        if (
                          newmeterreading.assetmeterid === element.assetmeterid
                        ) {
                          element.newreading = newmeterreading.newreading;
                          element.newreadingdate =
                            newmeterreading.newreadingdate;

                          let newreadingdate = element.newreadingdate
                            ? dataFormatter.dateWithoutTimeZone(
                              dataFormatter.convertISOtoDate(
                                element.newreadingdate
                              )
                            )
                            : "";
                          let lastreadingdate = element.lastreadingdate
                            ? dataFormatter.dateWithoutTimeZone(
                              dataFormatter.convertISOtoDate(
                                element.lastreadingdate
                              )
                            )
                            : "";

                          if (
                            newreadingdate &&
                            lastreadingdate &&
                            newreadingdate >= lastreadingdate
                          ) {
                            element.lastreading = element.newreading;
                            element.lastreadingdate = element.newreadingdate;
                            element.computedReading = element.newreading;
                            element.computedReadingDate =
                              element.newreadingdate;
                          } else if (
                            newreadingdate &&
                            lastreadingdate &&
                            newreadingdate < lastreadingdate
                          ) {
                            element.computedReading = element.lastreading;
                            element.computedReadingDate = lastreadingdate;
                          } else if (newreadingdate && !lastreadingdate) {
                            element.computedReading = element.newreading;
                            element.computedReadingDate =
                              element.newreadingdate;
                            element.lastreading = element.newreading;
                            element.lastreadingdate = element.newreadingdate;
                          } else {
                            element.computedReading = element.newreading;
                            element.computedReadingDate =
                              element.newreadingdate;
                          }
                          element.newreadingFlag = true;
                        }
                      }
                    });
                  }
                } finally {
                  assetMeterDs.off("put-data-failed", WOUtil.onSaveDataFailed);
                  page.state.useConfirmDialog = false;
                }
              }
            }
          }
        }
      }
      //Saving location meter readings
      if (
        locationMeterDs &&
        (locationMeterDs.name === "wolocationmeters" ||
          locationMeterDs.name.includes(
            "cds_tasklistMeterds.activelocationmeter"
          ) ||
          locationMeterDs.name.includes(
            "cds_woMultiAssetLocationds.activelocationmeter"
          ))
      ) {
        // istanbul ignore if
        if (locationMeterDs && locationMeterDs.items.length > 0) {
          for (let j = 0; j < locationMeterDs.items.length; j++) {
            let udpatedLocMeterObj = locationMeterDs.items[j];

            // istanbul ignore if
            if (typeof udpatedLocMeterObj.newreading !== "undefined") {
              let newLocReadingDate = page.state.newReading
                ? udpatedLocMeterObj.computedMeterCurDate
                : assetMeterDs.item.computedMeterCurDate;
              let newLocationTime = page.state.newReading
                ? udpatedLocMeterObj.computedMeterCurTime
                : assetMeterDs.item.computedMeterCurTime;

              // istanbul ignore if
              if (page.state.oldReading === true) {
                if (
                  locationMeterDs.name.includes(
                    "cds_woMultiAssetLocationds.activelocationmeter"
                  )
                ) {
                  newLocReadingDate = app.findDatasource(
                    "woMultiAssetLocationds"
                  ).item.computedMeterCurDate;
                  newLocationTime = app.findDatasource("woMultiAssetLocationds")
                    .item.computedMeterCurTime;
                } else if (
                  locationMeterDs.name.includes(
                    "cds_tasklistMeterds.activelocationmeter"
                  )
                ) {
                  newLocReadingDate =
                    app.findDatasource("tasklistMeterds").item
                      .computedMeterCurDate;
                  newLocationTime =
                    app.findDatasource("tasklistMeterds").item
                      .computedMeterCurTime;
                }
              }

              newLocReadingDate = dataFormatter.dateWithoutTimeZone(
                dataFormatter.convertISOtoDate(newLocReadingDate)
              );
              newLocationTime = newLocationTime
                ? dataFormatter.dateWithoutTimeZone(
                  dataFormatter.convertISOtoDate(newLocationTime)
                )
                : "";

              newLocReadingDate.setHours(
                newLocationTime ? newLocationTime.getHours() : 0
              );
              newLocReadingDate.setMinutes(
                newLocationTime ? newLocationTime.getMinutes() : 0
              );
              newLocReadingDate.setMilliseconds(0);
              newLocReadingDate.setSeconds(0);

              // istanbul ignore if
              if (page.state.rollOverData && udpatedLocMeterObj.rollover) {
                page.state.rollOverData.forEach((element, index) => {
                  if (
                    element.item.locationmeterid ===
                    udpatedLocMeterObj.locationmeterid
                  ) {
                    if (page.state.rollOverData[index].dorollover) {
                      udpatedLocMeterObj.dorollover = true;
                    } else if (!page.state.rollOverData[index].dorollover) {
                      udpatedLocMeterObj.newreading =
                        udpatedLocMeterObj.lastreading;
                    }
                  }
                });
              }

              // istanbul ignore else
              if (
                udpatedLocMeterObj.newreading === 0 ||
                udpatedLocMeterObj.newreading
              ) {
                let newLocationMeterReading = {
                  locationmeterid: udpatedLocMeterObj.locationmeterid,
                  location: udpatedLocMeterObj.location,
                  dorollover: udpatedLocMeterObj.dorollover
                    ? udpatedLocMeterObj.dorollover
                    : false,
                  inspector: app.client.userInfo.personid,
                  isdelta: false,
                  linearassetmeterid: 0,
                  metername: udpatedLocMeterObj.metername,
                  newreading: udpatedLocMeterObj.newreading,
                  newreadingdate: newLocReadingDate,
                  href: udpatedLocMeterObj.href,
                };

                let option = {
                  responseProperties: "lastreading,newreading,newreadingdate",
                  localPayload: newLocationMeterReading,
                  relationship: "activelocationmeter",
                  useRecordHref: true,
                };

                try {
                  app.userInteractionManager.drawerBusy(true);
                  ctrl.saveDataSuccessful = true;
                  assetMeterDs.on("put-data-failed", WOUtil.onSaveDataFailed);
                  let updatedResponse = await locationMeterDs.put(
                    newLocationMeterReading,
                    option
                  );
                  // istanbul ignore next
                  if (updatedResponse && ctrl.saveDataSuccessful) {
                    locationMeterDs.items.forEach((element) => {
                      if (element.newreading) {
                        if (
                          newLocationMeterReading.newreading &&
                          newLocationMeterReading.locationmeterid ===
                          element.locationmeterid
                        ) {
                          element.newreading =
                            newLocationMeterReading.newreading;
                          element.newreadingdate =
                            newLocationMeterReading.newreadingdate;

                          let newreadingdate = element.newreadingdate
                            ? dataFormatter.dateWithoutTimeZone(
                              dataFormatter.convertISOtoDate(
                                newLocationMeterReading.newreadingdate
                              )
                            )
                            : "";
                          let lastreadingdate = element.lastreadingdate
                            ? dataFormatter.dateWithoutTimeZone(
                              dataFormatter.convertISOtoDate(
                                element.lastreadingdate
                              )
                            )
                            : "";

                          if (
                            newreadingdate &&
                            lastreadingdate &&
                            newreadingdate >= lastreadingdate
                          ) {
                            element.lastreading =
                              newLocationMeterReading.newreading;
                            element.lastreadingdate = element.newreadingdate;
                            element.computedReading =
                              newLocationMeterReading.newreading;
                            element.computedReadingDate =
                              newLocationMeterReading.newreadingdate;
                          } else if (
                            newreadingdate &&
                            lastreadingdate &&
                            newreadingdate < lastreadingdate
                          ) {
                            element.computedReading =
                              newLocationMeterReading.lastreading;
                            element.computedReadingDate = lastreadingdate;
                          } else if (newreadingdate && !lastreadingdate) {
                            element.computedReading =
                              newLocationMeterReading.newreading;
                            element.computedReadingDate =
                              element.newreadingdate;
                            element.lastreading =
                              newLocationMeterReading.newreading;
                            element.lastreadingdate = element.newreadingdate;
                          } else {
                            element.computedReading = element.newreading;
                            element.computedReadingDate =
                              element.newreadingdate;
                          }
                        }
                      }
                    });
                  }
                } finally {
                  assetMeterDs.off("put-data-failed", WOUtil.onSaveDataFailed);
                  page.state.useConfirmDialog = false;
                }
              }
            }
          }
        }
      }
    } finally {
      app.userInteractionManager.drawerBusy(false);
    }
  }

  /*
    ********** PAGE FailureDetails( **********
    */
  pageInitFailureDetails(page) {
    let failureCtrl = page.controllers[0];
    failureCtrl.loadRecord = async () => {
      await this.custLoadRecord(failureCtrl);
    }
  }

  async custLoadRecord(ctrl) {
    const workorder = this.page.params.workorder;
    this.page.state.workorder = workorder;
    this.page.state.deletFailReportList = [];
    const failureLstDS = this.page.datasources['dsfailureDetailsList'];

    let reportWorkPage = this.app.pages.find((element) => {
      if (element.name === "report_work") {
        return element;
      } else {
        return '';
      }
    });

    // istanbul ignore else
    if (reportWorkPage && reportWorkPage !== '' &&
      reportWorkPage.datasources['woDetailsReportWork']) {
      this.page.woDetailsReportWorkDS = reportWorkPage.datasources['woDetailsReportWork'];
    }

    log.t("AppCustomizations", 'loadRecord :: woDetailsReportWorkDS items --> ' + this.page.woDetailsReportWorkDS.items);
    failureLstDS.clearSelections();

    let failureListArr = [];

    let placeHolderValues = [{ title: this.app.getLocalizedLabel('fail_class_placeholder', 'Failure class'), type: 'FAILURECLASS', type_maxvalue: 'FAILURECLASS' },
    { title: this.app.getLocalizedLabel('problem_placeholder', 'Problem'), type: 'PROBLEM', type_maxvalue: 'PROBLEM' },
    { title: this.app.getLocalizedLabel('cause_placeholder', 'Cause'), type: 'CAUSE', type_maxvalue: 'CAUSE' },
    { title: this.app.getLocalizedLabel('remedy_placeholder', 'Remedy'), type: 'REMEDY', type_maxvalue: 'REMEDY' }];

    let setReadonly = false;
    let parent = '';

    if (workorder && workorder.failurecode && workorder.failurecode.length > 0) {
      failureListArr.push({
        title: placeHolderValues[0].title,
        failurecode: workorder.failurecode,
        description: workorder.failure.description,
        failurelistid: 0,
        failurelist: workorder.failure.failurelist.failurelist,
        type: placeHolderValues[0].type,
        type_description: placeHolderValues[0].title,
        type_maxvalue: placeHolderValues[0].type_maxvalue,
        parent: '',
        orgid: workorder.orgid,
        readonly: false,
        href: workorder.href
      })
      parent = workorder.failure.failurelist.failurelist;
    } else {
      failureListArr.push({
        'title': placeHolderValues[0].title,
        failurelistid: 0,
        failurelist: '',
        type: placeHolderValues[0].type,
        type_description: placeHolderValues[0].title,
        type_maxvalue: placeHolderValues[0].type_maxvalue,
        failurecode: '',
        description: '',
        parent: '',
        orgid: workorder.orgid,
        readonly: false
      });
      setReadonly = true;
    }

    let problem;
    let i = 1;

    // check there is problem on failurereport. 
    if (workorder && workorder.failurecode && workorder.failurereport) {
      problem = workorder.failurereport.find((failurereport) => (failurereport.type_maxvalue === 'PROBLEM'));
    }

    // if there is no problem on failurereport, it assumes that problem set on offline mode.
    // istanbul ignore else
    if (!problem) {
      if (workorder && workorder.problemcode && workorder.problemcode.length > 0) {
        // istanbul ignore next
        failureListArr.push({
          title: placeHolderValues[1].title,
          failurecode: workorder.problemcode,
          description: workorder.problem.description,
          failurelistid: 1,
          failurelist: workorder.problem.failurelist.failurelist,
          type: placeHolderValues[1].type,
          type_description: placeHolderValues[1].title,
          type_maxvalue: placeHolderValues[1].type_maxvalue,
          parent: parent,
          orgid: workorder.orgid,
          readonly: false,
          href: workorder.href
        });
        // istanbul ignore next
        parent = workorder.problem.failurelist.failurelist;
      } else {
        failureListArr.push({
          'title': placeHolderValues[1].title,
          failurelistid: 1,
          failurelist: '',
          type: placeHolderValues[1].type,
          type_description: placeHolderValues[1].title,
          type_maxvalue: placeHolderValues[1].type_maxvalue,
          failurecode: '',
          description: '',
          parent: parent,
          orgid: workorder.orgid,
          readonly: setReadonly
        });
        setReadonly = true;
      }
      i = 2;
    }

    // istanbul ignore else
    if (workorder) {
      // istanbul ignore else
      if (workorder.failurereport) {
        const failurelists = [];
        workorder.failurereport.forEach((failurereport) => {
          failurelists.push(failurereport.linenum);
        });

        // get failure information from failure list because there is no failure list information when failure is set on offline mode.
        let dsfailureList = this.page.dsFailureList;
        await dsfailureList.initializeQbe();
        dsfailureList.setQBE('failurelist', 'in', failurelists);
        const failures = await dsfailureList.searchQBE();
        //IT02942699 - Additional variables to temporary store info. 
        let tempProblemObject;
        let tempCauseObject;
        let tempRemedyObject;
        workorder.failurereport.forEach((failurereport) => {
          // ignore deleted record on offline mode.
          // istanbul ignore else
          if (failurereport._action !== "delete") {
            const failure = failures.find((f) => f.failurelist === failurereport.linenum);
            let recordIndex = failureListArr.findIndex((record) => (record.type_maxvalue === failurereport.type_maxvalue));

            /* istanbul ignore if */
            if (failure) {
              // update failure information if failure type already exist in array
              if (recordIndex !== -1) {
                failureListArr[recordIndex].failurecode = failure.failurecode.failurecode;
                failureListArr[recordIndex].description = failure.failurecode.description;
                failureListArr[recordIndex].failurelist = failure.failurelist;
                failureListArr[recordIndex].type = failure.type;
                failureListArr[recordIndex].type_description = failure.type_description;
                failureListArr[recordIndex].type_maxvalue = failure.type_maxvalue;
                failureListArr[recordIndex].href = failurereport.href;
                failureListArr[recordIndex].readonly = false;
              } else {
                //IT02942699 - Check if incorrect order, i=1 should be PROBLEM CODE, i=2 CAUSE and i=3 REMEDY
                if (failure.type === "REMEDY") {
                  tempRemedyObject = {
                    title: failurereport.type_description,
                    failurecode: failure.failurecode.failurecode,
                    description: failure.failurecode.description,
                    failurelistid: 3,
                    failurelist: failure.failurelist,
                    type: failure.type,
                    type_description: failure.type_description,
                    type_maxvalue: failure.type_maxvalue,
                    orgid: workorder.orgid,
                    parent: parent,
                    href: failurereport.href,
                    readonly: false
                  };
                }
                else if (failure.type === "CAUSE") {
                  tempCauseObject = {
                    title: failurereport.type_description,
                    failurecode: failure.failurecode.failurecode,
                    description: failure.failurecode.description,
                    failurelistid: 2,
                    failurelist: failure.failurelist,
                    type: failure.type,
                    type_description: failure.type_description,
                    type_maxvalue: failure.type_maxvalue,
                    orgid: workorder.orgid,
                    parent: parent,
                    href: failurereport.href,
                    readonly: false
                  };
                }
                else if (failure.type === "PROBLEM") {
                  tempProblemObject = {
                    title: failurereport.type_description,
                    failurecode: failure.failurecode.failurecode,
                    description: failure.failurecode.description,
                    failurelistid: 1,
                    failurelist: failure.failurelist,
                    type: failure.type,
                    type_description: failure.type_description,
                    type_maxvalue: failure.type_maxvalue,
                    orgid: workorder.orgid,
                    parent: parent,
                    href: failurereport.href,
                    readonly: false
                  };
                }

                i++;
              }
              parent = failure.failurelist;
            }
          }
        });
        //IT02942699 - Push to array in correct order  
        if (tempProblemObject) {
          failureListArr.push(tempProblemObject);
        }
        if (tempCauseObject) {
          failureListArr.push(tempCauseObject);
        }
        if (tempRemedyObject) {
          failureListArr.push(tempRemedyObject);
        }
      }

      while (i < 4) {
        failureListArr.push({
          title: placeHolderValues[i].title,
          failurelistid: i,
          failurelist: '',
          type: placeHolderValues[i].type,
          type_description: placeHolderValues[i].title,
          type_maxvalue: placeHolderValues[i].type_maxvalue,
          failurecode: '',
          description: '',
          orgid: workorder.orgid,
          parent: parent,
          readonly: setReadonly
        });
        //type = '';  
        parent = '';
        setReadonly = true;
        i++;
      }
    }

    //istanbul ignore else
    if (Device.get().isMaximoMobile) {
      let enableIndexCheck = true;
      failureListArr.forEach((element, index) => {
        if ((element.type_maxvalue === 'FAILURECLASS' && workorder.failureclassdelete) || (element.type_maxvalue === 'PROBLEM' && workorder.problemdelete) ||
          (element.type_maxvalue === 'CAUSE' && workorder.causedelete) || (element.type_maxvalue === 'REMEDY' && workorder.remedydelete)) {
          failureListArr[index].description = '';
          failureListArr[index].failurecode = '';
          failureListArr[index].failurelist = '';
          failureListArr[index].readonly = true;
          //istanbul ignore else
          if (enableIndexCheck) {
            failureListArr[index].readonly = false;
            enableIndexCheck = false;
          }
        }
      });
    }

    await failureLstDS.load({ src: failureListArr, noCache: true });
    this.page.state.failureListArr = failureListArr;

    this.page.state.wofaildate = workorder.faildate;

    ctrl.resetFailureList(failureListArr);

    // set previously set remark
    this.page.state.failureRemark = workorder.remarkdesc ? workorder.remarkdesc : /*istanbul ignore next*/'';

    // set maximum length of remark text-area through checking datasource schema
    const workorderDS = this.page.woDetailsReportWorkDS;
    // istanbul ignore else
    if (workorderDS) {
      const remarkDescMaxLength = workorderDS.getFieldSize('remarkdesc');
      // istanbul ignore else
      if (remarkDescMaxLength !== -1) {
        this.page.state.failureRemarkMaxLength = remarkDescMaxLength;
      }
    }
  }

  async loadReportedHours(evt) {
    this.app.state.pageLoading = true;
    const today = new Date(); // Today's date
    let dsToFill = this.app.findDatasource("jReportedWork");
    let hoursMapDs = this.app.findDatasource("jhoursMapDS");

    //if this method is called via the user changing the dropdown, clear the selected days
    if (evt.calledFromDropdown === true) {
      hoursMapDs.clearSelections();
    }
    // Calculate the difference to Monday and Sunday for the current week
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    const diffToMonday = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek; // Days from today to this Monday
    const diffToSunday = dayOfWeek === 0 ? 0 : 7 - dayOfWeek; // Days from today to this Sunday

    // Set first and last day of the week based on evt.selectedItem.id
    let fromReportDate, toReportDate;
    if (evt.selectedItem.id === "thisWeek") {

      fromReportDate = new Date(today);
      fromReportDate.setDate(today.getDate() + diffToMonday);

      toReportDate = new Date(today);
      toReportDate.setDate(today.getDate() + diffToSunday);
    } else if (evt.selectedItem.id === "lastWeek") {
      fromReportDate = new Date(today);
      fromReportDate.setDate(today.getDate() + diffToMonday - 7);

      toReportDate = new Date(today);
      toReportDate.setDate(today.getDate() + diffToSunday - 7);
    }
    fromReportDate.setHours(0, 0, 0, 0);
    toReportDate.setHours(23, 59, 59);

    let totalReportedHrs = 0;

    try {
      dsToFill.state.loading = true;
      let woDs = this.app.findDatasource("custWorkOrders");
      await woDs.forceSync();

      let tempArray = [];
      const dayHoursMap = {
        monday: { hours: 0, premiumpayhours: 0 },
        tuesday: { hours: 0, premiumpayhours: 0 },
        wednesday: { hours: 0, premiumpayhours: 0 },
        thursday: { hours: 0, premiumpayhours: 0 },
        friday: { hours: 0, premiumpayhours: 0 },
        saturday: { hours: 0, premiumpayhours: 0 },
        sunday: { hours: 0, premiumpayhours: 0 },
      }; // A map to track hours for each day

      woDs.items.forEach((x) => {
        x.labtrans.forEach((y) => {
          //remove timezone and just look at the date
          //attribute to use differs between mobile and RBA
          if (!Device.get().isMaximoMobile) {
            y.startdateentered = this.app.dataFormatter.dateWithoutTimeZone(
              y.startdateentered
            );
          } else {
            y.startdateentered = this.app.dataFormatter.dateWithoutTimeZone(
              y.startdate
            );
          }
          let startdateentered = new Date(y.startdateentered);
          if (
            startdateentered >= fromReportDate &&
            startdateentered <= toReportDate &&
            y.laborcode === this.app.client.userInfo.labor.laborcode
          ) {
            y.description = x.description;
            y.wonum = x.wonum;
            y.href = x.href;

            // Get the name of the day (e.g., 'Monday', 'Tuesday', etc.)
            const dayName = startdateentered
              .toLocaleString("en-US", { weekday: "long" })
              .toLowerCase();

            // Check if the day exists in the map and update its hours
            if (dayHoursMap[dayName]) {
              const regularHours = y.regularhrs || 0;
              const premiumpayhours = y.premiumpayhours || 0;

              dayHoursMap[dayName].hours += regularHours;
              dayHoursMap[dayName].premiumpayhours += premiumpayhours
            }

            // Add a dynamic attribute to the transaction for the specific day
            const attributeKey = `${dayName}Hours`;
            const premiumattributeKey = `${dayName}premiumHours`;

            y[attributeKey] = dayHoursMap[dayName].hours;
            y[premiumattributeKey] = dayHoursMap[dayName].premiumpayhours;

            totalReportedHrs += y.regularhrs || 0;

            tempArray.push(y);
          }
        });
      });

      this.page.state.totalReportedHrs = totalReportedHrs;

      const tempArr2 = [];

      //translate days into correct locale, since this can't be handled via the locale jsons
      const startOfWeek = new Date(fromReportDate);
      Object.keys(dayHoursMap).forEach((day, index) => {
        let originalDay = day;
        let defaultSite = this.app.client.userInfo.defaultSite;
        let locale =
          defaultSite === "HYSE"
            ? "sv-SE"
            : defaultSite === "HYFI"
              ? "fi-FI"
              : "en-US";
        day = this.translateDay(
          day,
          locale
        );

        const currentDayDate = new Date(startOfWeek);
        currentDayDate.setDate(startOfWeek.getDate() + index);
        tempArr2.push({
          day: { day, currentDayDate },
          hours: dayHoursMap[originalDay].hours,
          premiumpayhours: dayHoursMap[originalDay].premiumpayhours
        });
      });

      // fill the DS that renders the reported hours per day
      await hoursMapDs.load({ src: tempArr2, noCache: true });

      //fill the ds that renders the work order information
      await dsToFill.load({ src: tempArray, noCache: true });
      this.app.state.pageLoading = false;

    } catch (error) {
      console.log("error:", error);
      this.app.state.pageLoading = false;
    }
  }

  translateDay(day, locale) {
    const weekdays = [
      "sunday",
      "monday",
      "tuesday",
      "wednesday",
      "thursday",
      "friday",
      "saturday",
    ];

    // Convert the input day to lowercase and find its index
    const dayIndex = weekdays.indexOf(day.toLowerCase());
    if (dayIndex === -1) {
      throw new Error("Invalid day name");
    }

    // Create a new date with the day set to a fixed date corresponding to the dayIndex
    const date = new Date(2023, 0, 1 + dayIndex); // January 1, 2023, was a Sunday

    const formatter = new Intl.DateTimeFormat(locale, { weekday: "long" });
    const translatedDay = formatter.format(date)

    return translatedDay.charAt(0).toUpperCase() + translatedDay.slice(1);
  }

  custnavigateToReportWork(item) {
    if (this.app && this.page && item && item.href) {
      this.app.setCurrentPage({
        name: "report_work",
        params: {
          wonum: item.wonum,
          itemhref: item.href,
        },
      });
      if (this.app.currentPage) {
        this.page.state.navigateToReportWork = true;
      }
    }
  }

  async refreshReportedHours() {
    let event = {};
    event.selectedItem = { id: this.page.state.timeFrame };
    await this.loadReportedHours(event);
  }

  async selectDayWithReportedHours() {
    let event = {};
    event.selectedItem = { id: this.page.state.timeFrame };
    const ds = this.app.findDatasource("jhoursMapDS");
    let selected = ds.getSelectedItems();
    let dsToFill = this.app.findDatasource("jReportedWork");
    if (selected.length >= 1) {
      await this.loadReportedHours(event);

      dsToFill.state.loading = true;

      let tempArr = [];
      selected.forEach((x) => {
        dsToFill.forEach((y) => {
          let isoDate = new Date(y.startdateentered);
          let selectedIsoDate = new Date(x.day.currentDayDate);
          if (
            isoDate.getUTCFullYear() === selectedIsoDate.getUTCFullYear() &&
            isoDate.getUTCMonth() === selectedIsoDate.getUTCMonth() &&
            isoDate.getUTCDate() === selectedIsoDate.getUTCDate()
          ) {
            tempArr.push(y);
          }
        });
      });

      await dsToFill.load({ src: tempArr, noCache: true });
    } else {
      //if the selected items array is less than 1, no days are selected and we call the load method to reload it without any days selected
      await this.loadReportedHours(event);
    }
  }


  async dialogInitialized(page) {
    if (page.name === "woStatusChangeDialog") {
      let c = page.controllers[0];
      let oldchangeStatus = c.changeStatus.bind(c);

      c.changeStatus = async () => {
        localStorage.setItem(`${page}scrollpos`, window.scrollY);
        await oldchangeStatus();
        this.getScrollPosition(page)
      }
    }
  }

  //method to open risk analysis form
  openRiskAnalysis(wonum) {
    let defaultSite = this.app.client.userInfo.defaultSite;
    let baseURL =
      defaultSite === "HYSE"
        ? "https://app.gate-apps.com/fortum-vesivoima/anonymous/tyoluvat/form-entry/c4423cda-c650-45b9-8311-f036aa40f7d0?lang=se"
        : defaultSite === "HYFI"
          ? "https://app.gate-apps.com/fortum-vesivoima/anonymous/tyoluvat/form-entry/087d7670-0951-4ce8-9b59-08a02af58d06?lang=fi"
          : undefined;

    baseURL += "&wonum=" + wonum + "&name=" + encodeURIComponent(this.app.client.userInfo.displayname);

    if (baseURL) {
      if (!Device.get().isMaximoMobile) {
        try {
          Browser.get().openURL(
            baseURL,
            "_blank",
            "location=no,hidden=yes"
          );
        } catch (error) {
          console.log("Error: ", error);
        }
      } else {
        try {
          window.cordova.InAppBrowser.open(
            baseURL,
            "_blank",
            "location=no"
          );
        } catch (error) {
          console.log("Error: ", error);
        }
      }
    }
  }

}

export default AppCustomizations;